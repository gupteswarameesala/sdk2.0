package com.opsramp.app.processor.monitor;

import java.sql.Timestamp;
import java.text.MessageFormat;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

import org.apache.http.HttpResponse;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;

import com.fasterxml.uuid.Generators;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.opsramp.app.content.util.JsonUtil;
import com.opsramp.app.processor.api.APITemplate;
import com.opsramp.app.processor.api.APIUtil;
import com.opsramp.app.util.AppConstants;
import com.opsramp.app.util.BaseUtil;

/**
 * @author gopi
 *
 */
public class MonitorProcessorUtil {

	private static Logger LOG = org.slf4j.LoggerFactory.getLogger(MonitorProcessorUtil.class);

	/**
	 * @param apiTemplate
	 * @param apiUrl
	 * @param resourceId
	 * @param nativeType
	 * @param moId
	 * @param metrics 
	 * @return
	 * @throws Exception
	 */
	public static List<JsonObject> getMetricsData(APITemplate apiTemplate, String apiUrl, String resourceId,
			String nativeType, String moId, Set<String> metrics) throws Exception {

		LOG.error("MonitorProcessorUtil# getMetricsData# call started ...");

		List<JsonObject> metricsPayloadList = new ArrayList<JsonObject>();
		String url = null;
		try {
			String[] hostIdStr = moId.split("@");
			String hostId = hostIdStr[1];
			LOG.error("For metric moId : " + moId);
			LOG.error("For metric nativeType : " + nativeType);

			JsonObject tags= null;
			if (nativeType.equalsIgnoreCase(AppConstants.HOSTS)) {
				url = MessageFormat.format(apiUrl, hostId);
				tags = new JsonObject();
				tags.addProperty("vcenter", hostIdStr[0]);
				LOG.error("For host metric url : " + url);
				prepareHostMetrics(apiTemplate, metricsPayloadList, url,metrics,tags);
			} else if (nativeType.equalsIgnoreCase(AppConstants.VMS)) {
				url = MessageFormat.format(apiUrl, hostId, hostIdStr[2]);
				tags = new JsonObject();
				tags.addProperty("host", hostId);
				LOG.error("For vm metric url : " + url);
				String vmuniqueId = hostIdStr[0]+hostId + hostIdStr[2];
				prepareVmsMetrics(apiTemplate, metricsPayloadList, url, vmuniqueId, hostId,metrics,tags);
			}

			LOG.error("MonitorProcessorUtil# getMetricsData# call ended ...");

		} catch (Exception e) {
			LOG.error("Unable to get Metrics data List Reason :" + e.getMessage(), e);
			throw e;
		}
		return metricsPayloadList;
	}

	private static void prepareHostMetrics(APITemplate apiTemplate, List<JsonObject> metricsPayloadList, String baseUrl, Set<String> metrics, JsonObject tags)
			throws Exception {
		String metricResBodyStr = null;
		//String url = baseUrl + AppConstants.FORWORD_SLASH + "metrics";
		LOG.error("MonitorProcessorUtil# prepareHostMetrics# call started ...");

		try {
			metricResBodyStr = getAPIResponse(apiTemplate, baseUrl, null);
			// JSONArray Conversion
			JSONArray monitorJsonArray = new JSONArray(metricResBodyStr);
			prepareHostMetricsList(monitorJsonArray, metricsPayloadList,metrics,tags);

			LOG.error("MonitorProcessorUtil# prepareHostMetrics# call ended ...");

		} catch (Exception e) {
			LOG.error("Failed to prepare Gateway Profile Metrics List Reason :" + e.getMessage(), e);
			throw e;
		}

	}

	/**
	 * @param apiTemplate
	 * @param metricsPayloadList
	 * @param baseUrl
	 * @param vmuniqueId
	 * @param hostId
	 * @param metrics 
	 * @param tags 
	 * @throws Exception
	 */
	private static void prepareVmsMetrics(APITemplate apiTemplate, List<JsonObject> metricsPayloadList, String baseUrl,
			String vmuniqueId, String hostId, Set<String> metrics, JsonObject tags) throws Exception {
		String metricResBodyStr = null;
		LOG.error("MonitorProcessorUtil# prepareVmsMetrics# call started ...");
		try {
			metricResBodyStr = getAPIResponse(apiTemplate, baseUrl, null);
			// JSONArray Conversion
			JSONArray monitorJsonArray = new JSONArray(metricResBodyStr);
			prepareVmsMetricsList(monitorJsonArray, metricsPayloadList, vmuniqueId,metrics,tags);

			LOG.error("MonitorProcessorUtil# prepareVmsMetrics# call ended ...metricResBodyStr :: " + metricResBodyStr);
		} catch (Exception e) {
			throw e;
		}

	}

	/**
	 * @param monitorJsonArray
	 * @param metricsPayloadList
	 * @param vmuniqueId
	 * @param metrics 
	 * @param tags 
	 * @return
	 * @throws Exception
	 */
	public static List<JsonObject> prepareVmsMetricsList(JSONArray monitorJsonArray,
			List<JsonObject> metricsPayloadList, String vmuniqueId, Set<String> metrics, JsonObject tags) throws Exception {
		LOG.error("MonitorProcessorUtil# prepareVmsMetricsList# method started ...");
		try {
			if (monitorJsonArray.isEmpty() || monitorJsonArray == null) {
				throw new Exception("MonitorProcessorUtil# prepareVmsMetricsList# monitor received as empty");
			}
			 Random rand = new Random(); //instance of random class
		     //generate random values from 0-24
		      int randomNum = rand.nextInt(5); 
			for (int i = 0; i < monitorJsonArray.length(); i++) {
				JSONObject monitorVMObj = (JSONObject) monitorJsonArray.get(i);
				JSONArray monVmArrObj = monitorVMObj.getJSONArray(vmuniqueId);
				for (int j = 0; j < monVmArrObj.length(); j++) {
					JSONObject monitorObj = (JSONObject) monVmArrObj.get(j);

					JsonObject metricData = new JsonObject();
					String metricname = monitorObj.getString("name").replace(".", "_");
					if(metrics.contains(metricname) && metricname.equalsIgnoreCase("system_cpu_load")) {
						metricData = BaseUtil.metricsCloudFormatConveter(metricname, monitorObj.getString("name"),
								String.valueOf(randomNum),tags);
						metricsPayloadList.add(metricData);
					} else {
					if (metrics.contains(metricname)) {
						metricData = BaseUtil.metricsCloudFormatConveter(metricname, monitorObj.getString("name"),
								String.valueOf(monitorObj.getFloat("value")),tags);
						metricsPayloadList.add(metricData);
					}
					}
				}
			}
			LOG.error("MonitorProcessorUtil# prepareVmsMetricsList# method ended ...metricsPayloadList ::"
					+ metricsPayloadList);
		} catch (Exception e) {
			LOG.error("Unable to prepare Metrics List Reason :" + e.getMessage(), e);
		}
		return metricsPayloadList;
	}

	/**
	 * @param monitorJsonArray
	 * @param metricsPayloadList
	 * @param metrics 
	 * @param tags 
	 * @return
	 */
	public static List<JsonObject> prepareHostMetricsList(JSONArray monitorJsonArray,
			List<JsonObject> metricsPayloadList, Set<String> metrics, JsonObject tags) {

		LOG.error("MonitorProcessorUtil# prepareHostMetricsList# method started ...");

		try {
			for (int i = 0; i < monitorJsonArray.length(); i++) {
				JSONObject discoveryObj = (JSONObject) monitorJsonArray.get(i);
				JsonObject metricData = new JsonObject();
				String metricname = discoveryObj.getString("name").replace(".", "_");
				if (metrics.contains(metricname)) {
					metricData = BaseUtil.metricsCloudFormatConveter(metricname, discoveryObj.getString("name"),
							String.valueOf(discoveryObj.getFloat("value")),tags);
					metricsPayloadList.add(metricData);
				}
			}
			LOG.error("MonitorProcessorUtil# prepareHostMetricsList# method ended ...");
		} catch (Exception e) {
			LOG.error("Failed to prepare prepare Host Metrics List Reason :" + e.getMessage(), e);
		}

		return metricsPayloadList;
	}

	/**
	 * @param apiTemplate
	 * @param url
	 * @param body
	 * @return
	 * @throws Exception
	 */
	public static String getAPIResponse(APITemplate apiTemplate, String url, String body) throws Exception {
		LOG.error("MonitorProcessorUtil# getAPIResponse# call initiating ...");
		HttpResponse response = null;
		String metricResBodyJSONStr = null;
		try {
			try {
				LOG.error("url ::"+url);
				if (BaseUtil.isEmpty(body)) {
					response = apiTemplate.invokeGET(url);
				} else {
					response = apiTemplate.invokePOST(url, body);
				}
				if (response == null) {
					throw new Exception("Response recieved null for url: " + url);
				}
				LOG.error("response ::"+response);
				metricResBodyJSONStr = APIUtil.getResponseBody(response, null);
			} catch (Exception e) {
				throw e;
			}

			LOG.error("Success API Details, Url:" + url + " ,ReqPayload:" + body + " ,StatusCode:"
					+ response.getStatusLine().getStatusCode());
			LOG.error("MonitorProcessorUtil# getAPIResponse# call ended...");
		} catch (Exception ex) {
			LOG.error("Failed API Details, Url:" + url + " ,ReqPayload:" + body + " ,Exception details:"
					+ ex.getMessage(), ex);
			throw ex;
		}
		return metricResBodyJSONStr;
	}

	/**
	 * @param monitoringJsonObj
	 * @param metricDataList
	 * @param configId
	 * @param resourceId
	 * @param nativeType
	 * @throws Exception
	 */
	public static void publishMetricPayload(JsonObject monitoringJsonObj, List<JsonObject> metricDataList,
			String configId, String resourceId, String nativeType) throws Exception {
		LOG.error("MonitorProcessorUtil# publishMetricPayload# Publish Monitor Metrics started.");
		try {
			JsonObject genericPayload = new JsonObject();
			String appIntegrationId = JsonUtil.getString(monitoringJsonObj, "appIntegrationId");
			JsonObject  appPayload = JsonUtil.getJson(monitoringJsonObj, "payload");
			JsonObject  template = JsonUtil.getJson(appPayload, "template");
			
			String app = JsonUtil.getString(template, "app");//"mock-vcenters";
			String version = JsonUtil.getString(template, "messageVersion");// "2.0.0";

			String gatewayProfile = JsonUtil.getString(monitoringJsonObj, "managementProfileId");

			genericPayload.addProperty("version", version);
			UUID generate = Generators.timeBasedGenerator().generate();
			genericPayload.addProperty("id", generate.toString());
			genericPayload.addProperty("profile", gatewayProfile);
			genericPayload.addProperty("gateway", gatewayProfile);
			genericPayload.addProperty("collector", AppConstants.COLLECTOR);
			genericPayload.addProperty("app", app);
			genericPayload.addProperty("appId", appIntegrationId);
			genericPayload.addProperty("module", AppConstants.EMPTY_STRING);
			genericPayload.addProperty("type", AppConstants.MONITOR_TYPE);
			genericPayload.addProperty("subType", AppConstants.EMPTY_STRING);
			genericPayload.addProperty("action", AppConstants.ACTION);
			genericPayload.addProperty("configId", configId);

			// Prepare metric Payload with metric data prepared
			JsonObject payloadEntity = new JsonObject();
			String metricsDataJson = new Gson().toJson(metricDataList);
			JsonArray metricsDataJsonData = new Gson().fromJson(metricsDataJson, JsonArray.class);

			payloadEntity.add("data", metricsDataJsonData);
			payloadEntity.addProperty("id", resourceId);

			genericPayload.add("payload", payloadEntity);

			Timestamp timestampmills = new Timestamp(System.currentTimeMillis());
			Instant instant = timestampmills.toInstant();
			genericPayload.addProperty("timestamp", instant.toString());

			LOG.error("Generic Payload : " + genericPayload.toString());
			String monitorGenericRespJsonStr = null;
			monitorGenericRespJsonStr = genericPayload.toString();
			LOG.error("MonitorProcessorUtil# publishMetricPayload Final Cloud Monitor Metrics Payload -- : "
					+ monitorGenericRespJsonStr);
			try {
				AlertsDataProcessUtil.publishMetricsAndAlert(configId, monitoringJsonObj.toString(),
						monitorGenericRespJsonStr, nativeType);
				LOG.error("MonitorProcessorUtil# publishMetricPayload publish Monitor Request processed successfully");
			} catch (Exception e) {
				LOG.error("Failed to publish metrics payload : " + e.getMessage());
			}
		} catch (Exception e) {
			LOG.error("Failed to process publish metric payload : " + e.getMessage());
		}
		LOG.error("MonitorProcessorUtil# publishMetricPayload# Publish Monitor Metrics Ended.");
	}

	/**
	 * @param apiUrl
	 * @param dataObject
	 * @param nativeType
	 * @return
	 * @throws Exception
	 */
	public static String getMetricAPIs(String apiUrl, JsonObject dataObject, String nativeType) throws Exception {
		// TODO Auto-generated method stub
		LOG.error("MonitorDataProcessor# getMetricAPIsList# call started ...");
		String metricApi = null;
		try {
			String protocolStr = JsonUtil.getString(dataObject, "protocol");
			if (protocolStr == null || protocolStr.isEmpty()) {
				throw new Exception("Protocol should not be null or empty");
			}

			String ipAddress = JsonUtil.getString(dataObject, "ipAddress");
			if (ipAddress == null || ipAddress.isEmpty()) {
				throw new Exception("IP should not be null or empty");
			}

			String port = JsonUtil.getString(dataObject, "port");
			if (port == null || port.isEmpty()) {
				throw new Exception("Port should not be null or empty");
			}

			String vcenter = JsonUtil.getString(dataObject, "vcenterName");
			if (vcenter == null || vcenter.isEmpty()) {
				throw new Exception("Vcenter should not be null or empty");
			}

			if (nativeType.equalsIgnoreCase(AppConstants.HOSTS)) {
				metricApi = MessageFormat.format(apiUrl, protocolStr.trim(), ipAddress.trim(), port.trim(), vcenter.trim(),"{0}");
			} else if (nativeType.equalsIgnoreCase(AppConstants.VMS)) {
				metricApi = MessageFormat.format(apiUrl, protocolStr.trim(), ipAddress.trim(), port.trim(), vcenter.trim(),"{0}","{1}");
			}

			LOG.error("MonitorDataProcessor# getMetricAPIsList# call ended ...");
		} catch (Exception e) {
			LOG.error("Failed to get metrics API, Reason :" + e.getMessage(), e);
			throw e;
		}
		return metricApi;
	}

}