package com.opsramp.app.processor.discovery;

import java.lang.reflect.Type;
import java.sql.Timestamp;
import java.text.MessageFormat;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.http.HttpResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.uuid.Generators;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.opsramp.app.content.core.integration.RelationshipFilter;
import com.opsramp.app.content.core.integration.ServiceFactory;
import com.opsramp.app.content.util.JsonUtil;
import com.opsramp.app.processor.api.APITemplate;
import com.opsramp.app.processor.api.APIUtil;
import com.opsramp.app.util.AppConstants;
import com.opsramp.app.util.BaseUtil;
import com.opsramp.app.util.InternalCacheSore;
import com.opsramp.app.util.Md5Util;



/**
 * Util class to process all discovery related requests
 * 
 * @author Srini T
 *
 */
public class DiscoveryProcessorUtil {

	private static Logger LOG = LoggerFactory.getLogger(DiscoveryProcessorUtil.class);

	private static String DISCOVERY_BASE_URI = "{0}://{1}:{2}/api/v1/vcenters/{3}/hosts";

	/**
	 * this method publish the relationships to cloud
	 * 
	 * @param discoveryJsonObj
	 * @param array
	 * @throws Exception
	 */
	public static void publishRelationshipsToCloud(JsonObject discoveryJsonObj, JsonArray array) throws Exception {
		LOG.error("DiscoveryProcessorUtil# publishRelationshipsToCloud# call initiating... discoveryJsonObj ::"
				+ discoveryJsonObj.toString());

		if (array == null) {
			throw new Exception("No Data Found in Gateway Request");
		}
		try {
		//RelationshipFilter
		Type realtionType = new TypeToken<List<JsonObject>>() {
		}.getType();
		List<JsonObject> listOfRealtionShipTypes = new Gson().fromJson(array, realtionType);
		String messageId = JsonUtil.getString(discoveryJsonObj,"messageId");
		RelationshipFilter relationshipFilter=new RelationshipFilter(messageId,listOfRealtionShipTypes);
		List<JsonObject> listOfRelationshipFilters = relationshipFilter.filter();
		
		LOG.error("listOfRelationshipFilters -- : {}", listOfRelationshipFilters);
		JsonElement relationShipElement = new Gson().toJsonTree(listOfRelationshipFilters, new TypeToken<List<JsonObject>>() {}.getType());
        JsonArray relationShipArray = relationShipElement.getAsJsonArray();
		LOG.error("relationShipArray -- : {}", relationShipArray);

		
			JsonObject relationshipPayload = new JsonObject();
			relationshipPayload.addProperty("version", JsonUtil.getString(discoveryJsonObj, "messageVersion"));
			UUID generate = Generators.timeBasedGenerator().generate();
			relationshipPayload.addProperty("id", generate.toString());
			relationshipPayload.addProperty("profile", JsonUtil.getString(discoveryJsonObj, "managementProfileId"));
			relationshipPayload.addProperty("gateway", JsonUtil.getString(discoveryJsonObj, "managementProfileId"));
			relationshipPayload.addProperty("collector", AppConstants.COLLECTOR);
			relationshipPayload.addProperty("app", JsonUtil.getString(discoveryJsonObj, "app"));
			relationshipPayload.addProperty("appId", JsonUtil.getString(discoveryJsonObj, "appIntegrationId"));
			relationshipPayload.addProperty("module", AppConstants.EMPTY_STRING);
			relationshipPayload.addProperty("type", AppConstants.RELATIONSHIP_TYPE);
			relationshipPayload.addProperty("subType", AppConstants.EMPTY_STRING);
			relationshipPayload.addProperty("action", AppConstants.RELATION_ACTION);
			relationshipPayload.addProperty("configId", JsonUtil.getString(discoveryJsonObj, "configurationId"));

			relationshipPayload.add("payload", relationShipArray);//relationShipArray);

			Timestamp timestampmills1 = new Timestamp(System.currentTimeMillis());
			Instant instant1 = timestampmills1.toInstant();
			relationshipPayload.addProperty("timestamp", instant1.toString());
			String cloudRelationShipResponseString = relationshipPayload.toString();// gson.toJson(relationshipPayload);

			LOG.error("RelationShip Payload -- : {}", cloudRelationShipResponseString);
			try {
				ServiceFactory.getMessagePublisher().publish(cloudRelationShipResponseString);
			} catch (Exception e) {
				LOG.error("Unable to publish RelationShip Payload, Reason {}:" + e.getMessage(), e);
				throw new Exception("Unable to publish RelationShip Payload, Reason :" + e.getMessage() + e);
			}
		} catch (Exception e) {
			LOG.error("Unable to process Relationship Payload, Reason :" + e.getMessage(), e);
			throw new Exception("Unable to process Relationship Payload" + e.getMessage() + e);
		}
		LOG.error("DiscoveryProcessorUtil# publishRelationshipsToCloud# call completed...");
	}

	/**
	 * get the resource data from the target
	 * 
	 * @param configurationId
	 * @param apiTemplate
	 * @param payloadObj
	 * @param discoveryJsonObj 
	 * @param credJsonObj
	 * @param relationshipArray
	 * @param discoveryJsonObj 
	 * @param nativeType 
	 * @return
	 * @throws Exception
	 */
	public static List<JsonObject> getResources(String configurationId, APITemplate apiTemplate, JsonObject payloadObj,
			JsonObject discoveryJsonObj, String nativeType,String resourceType) throws Exception {

		LOG.error(" DiscoveryProcessorUtil# getResources# call started ...");

		List<JsonObject> resources = new ArrayList<>();
		try {
			JsonObject dataObject = JsonUtil.getJson(payloadObj, "data");

			String protocolStr = JsonUtil.getString(dataObject, "protocol");
			if (protocolStr == null || protocolStr.isEmpty()) {
				throw new Exception("Protocol should not be null or empty");
			}

			String ipAddress = JsonUtil.getString(dataObject, "ipAddress");
			if (ipAddress == null || ipAddress.isEmpty()) {
				throw new Exception("IP should not be null or empty");
			}

			String port = JsonUtil.getString(dataObject, "port");
			if (port == null || port.isEmpty()) {
				throw new Exception("Port should not be null or empty");
			}

			String vcenter = JsonUtil.getString(dataObject, "vcenterName");
			if (vcenter == null || vcenter.isEmpty()) {
				throw new Exception("Vcenter should not be null or empty");
			}

			String baseUrl = MessageFormat.format(DISCOVERY_BASE_URI, protocolStr.trim(), ipAddress.trim(), port.trim(), vcenter.trim());
			apiTemplate.setApiBaseURI(protocolStr.trim() + "://" + ipAddress.trim() + AppConstants.COLON + port.trim());
			JsonObject rootInfoCustomAttrbts = new JsonObject();
			JsonObject topResource = null;
			topResource = prepareRootResourcePayload(dataObject, resources, vcenter.trim());
			rootInfoCustomAttrbts.addProperty(AppConstants.ROOT_RESOURCE_IP_ADDR,
					JsonUtil.getString(dataObject, "ipAddress"));
            
			if(nativeType.equalsIgnoreCase(AppConstants.HOSTS)) {
				resources = prepareResourceDetails(apiTemplate, baseUrl,rootInfoCustomAttrbts,
					configurationId,discoveryJsonObj,resourceType);
			} else if(nativeType.equalsIgnoreCase(AppConstants.VMS)) {
				// prepare child resource
				resources = prepareVmsDetails(apiTemplate,baseUrl,rootInfoCustomAttrbts,configurationId,resourceType);
			}
			LOG.error(" DiscoveryProcessorUtil# getResources# call ended ..");
		} catch (Exception e) {
			LOG.error("Failed to process getResources() with error:" + e.getMessage(), e);
			throw e;
		}
		return resources;
	}

	/**
	 * get the response from provided API URL
	 * 
	 * @param apiTemplate
	 * @param url
	 * @return
	 * @throws Exception
	 */
	public static String getResponse(APITemplate apiTemplate, String url) throws Exception {
		String discoveryStr = null;
		HttpResponse response = null;

		LOG.error("DiscoveryProcessorUtil# getResponse# call started...");
		try {
			response = apiTemplate.invokeGET(url);
			discoveryStr = APIUtil.getResponseBody(response, null);
			if (BaseUtil.isEmpty(discoveryStr)) {
				throw new Exception("discoveryResBodyStr received as empty");
			}
			if (!APIUtil.isRequestSucceeded(response)) {
				int status = response.getStatusLine().getStatusCode();
				LOG.error("Failed to get Discovery Data, status:{}, error:{}", status, discoveryStr);
				throw new Exception("Failed to get discoveryData, Reason: " + discoveryStr);
			}
			LOG.error("DiscoveryProcessorUtil# getResponse# call ended...");
		} catch (Exception e) {
			LOG.error("Failed to process getResponse() with url : " + url + "    with error:" + e.getMessage() + e);
		}
		return discoveryStr;
	}

	/**
	 * verify whether resource required to publish or not
	 * 
	 * @param resourcePayload
	 * @param configurationId
	 * @return
	 */
	public static boolean isResourcePublishRequired(JsonObject resourcePayload, String configurationId) {
		String newResourceHashCode = null;
		String oldResourceHashCode = null;

		try {
			// prepare resourceHashCodekey by combination of MoID and ConfigId
			String resourceHashCodekey = resourcePayload.get("moId").getAsString() + "_" + configurationId;

			// Get previous resource payload HashCode by using resourceHashCodekey
			oldResourceHashCode = ServiceFactory.getCacheStore().get(AppConstants.RESOURCE_PAYLOAD_HASHCODE,
					resourceHashCodekey);

			// Generate HashCode by using MD5 Hash Algorithm
			newResourceHashCode = Md5Util.getMd5Hash(resourcePayload.toString());
			String publishingResourceId = ServiceFactory.getCacheStore().get(AppConstants.RESOURCESTORE,
					resourcePayload.get("moId").getAsString());

			if (!BaseUtil.isEmpty(oldResourceHashCode) && !BaseUtil.isEmpty(newResourceHashCode)
					&& oldResourceHashCode.equals(newResourceHashCode) && !BaseUtil.isEmpty(publishingResourceId)) {
				LOG.debug(resourcePayload.get("resourceType").getAsString() + ", moId:"
						+ resourcePayload.get("moId").getAsString()
						+ " Resource Payload details are already exists, so no need to publish.." + configurationId);
				return false;
			}
			// store the newly generated resource payload HashCode in dataStoreClient
			ServiceFactory.getCacheStore().put(AppConstants.RESOURCE_PAYLOAD_HASHCODE, resourceHashCodekey,
					newResourceHashCode);

			LOG.error(" resourceHashCodekey {} : ", resourceHashCodekey + "  newResourceHashCode {} : "
					+ newResourceHashCode + " successfully stored in " + AppConstants.RESOURCE_PAYLOAD_HASHCODE);
		} catch (Exception e) {
			LOG.error("Unable to Generate and Store resourceHashCodekey in " + AppConstants.RESOURCE_PAYLOAD_HASHCODE
					+ " : {}" + e.getMessage(), e);
		}
		return true;
	}

	/**
	 * publish the resource details to cloud
	 * 
	 * @param discoveryJsonObj
	 * @param resourcePayload
	 * @throws Exception
	 */
	public static void publishResourceToCloud(JsonObject discoveryJsonObj, JsonObject resourcePayload)
			throws Exception {
		LOG.error("DiscoveryProcessorUtil# publishResourceToCloud# call initiating...");
		JsonObject genericPayload = new JsonObject();
		String configurationId = JsonUtil.getString(discoveryJsonObj, "configurationId");

		genericPayload.addProperty("version", JsonUtil.getString(discoveryJsonObj, "messageVersion"));
		UUID generate = Generators.timeBasedGenerator().generate();
		genericPayload.addProperty("id", generate.toString());
		genericPayload.addProperty("profile", JsonUtil.getString(discoveryJsonObj, "managementProfileId"));
		genericPayload.addProperty("gateway", JsonUtil.getString(discoveryJsonObj, "managementProfileId"));
		genericPayload.addProperty("collector", AppConstants.COLLECTOR);
		genericPayload.addProperty("app", JsonUtil.getString(discoveryJsonObj, "app"));
		genericPayload.addProperty("appId", JsonUtil.getString(discoveryJsonObj, "appIntegrationId"));
		genericPayload.addProperty("module", "");
		genericPayload.addProperty("type", AppConstants.DISCOVERY_TYPE);
		genericPayload.addProperty("subType", "");
		genericPayload.addProperty("action", AppConstants.ACTION);
		genericPayload.add("payload", resourcePayload);
		genericPayload.addProperty("configId", configurationId);
		Timestamp timestampmillis = new Timestamp(System.currentTimeMillis());
		Instant instant = timestampmillis.toInstant();
		genericPayload.addProperty("timestamp", String.valueOf(instant));

		LOG.error("Final Cloud Response To Post -- : genericPayload :: {} ", genericPayload);

		try {
			ServiceFactory.getMessagePublisher().publish(genericPayload.toString());
			LOG.error("Request processed successfully");
		} catch (Exception e) {
			LOG.error("Unable to Process Generic Responses with configurationId: " + configurationId + ", Reason: "
					+ e.getMessage(), e);
			throw new Exception("Unable to publish discovery payload", e);
		}
		LOG.error("DiscoveryProcessorUtil# publishResourceToCloud# call ended...");
	}

	/**
	 * prepare root resource element
	 * 
	 * @param payloadData
	 * @param resources
	 * @param vcenter
	 * @return
	 */
	private static JsonObject prepareRootResourcePayload(JsonObject payloadData, List<JsonObject> resources,
			String vcenter) {

		LOG.error(" DiscoveryProcessorUtil# prepareTopResourcePayload# call started ...");
		JsonObject topResourceDets = new JsonObject();

		try {
			topResourceDets.addProperty("name", vcenter);
			topResourceDets.addProperty("ipAddress", JsonUtil.getString(payloadData, "ipAddress"));
			topResourceDets.addProperty("moId", vcenter);

			JsonObject resourcePayload = new JsonObject();
			resourcePayload.addProperty("resourceType", AppConstants.SERVER);
			resourcePayload.addProperty("resourceName", topResourceDets.get("name").getAsString());
			resourcePayload.addProperty("hostName", topResourceDets.get("ipAddress").getAsString());
			resourcePayload.addProperty("ipAddress", topResourceDets.get("ipAddress").getAsString());
			resourcePayload.addProperty("aliasName", topResourceDets.get("name").getAsString());
			resourcePayload.addProperty("moId", topResourceDets.get("moId").getAsString());
			resourcePayload.addProperty("nativeType", AppConstants.VCENTER_NATIVE_TYPE);
			resourcePayload.add(AppConstants.SDK_APP_NAME, topResourceDets);
			resources.add(resourcePayload);
			
		} catch (Exception e) {
			LOG.error("Getting error in method prepareTopResourcePayload  while parsing discovery data :"
					+ e.getMessage(), e);
			throw e;
		}
		LOG.error(" DiscoveryProcessorUtil# prepareTopResourcePayload# call ended ...");
		return topResourceDets;
	}

	/**
	 * prepare resource details
	 * 
	 * @param apiTemplate
	 * @param baseUrl
	 * @param rootInfoCustomAttrbts 
	 * @param resources
	 * @param rootInfoCustomAttrbts
	 * @param sourceMoid
	 * @param configurationId 
	 * @param discoveryJsonObj 
	 * @param resourceType 
	 * @return 
	 * @throws Exception
	 */
	private static List<JsonObject> prepareResourceDetails(APITemplate apiTemplate, String baseUrl,
			JsonObject rootInfoCustomAttrbts, String configurationId, JsonObject discoveryJsonObj, String resourceType) throws Exception {
		LOG.error("DiscoveryProcessorUtil# prepagerResourceDtails# call started...");
		 List<JsonObject> resources =new ArrayList<JsonObject>();
		try {

			String resourceDetails = getResponse(apiTemplate, baseUrl);
			JsonArray discoveryJSON = new Gson().fromJson(resourceDetails, JsonArray.class);
			for (int i = 0; i < discoveryJSON.size(); i++) {
				JsonObject discoveryObj = (JsonObject) discoveryJSON.get(i);

					JsonObject resourcePayload = new JsonObject();
					resourcePayload.addProperty("resourceType", resourceType);
					resourcePayload.addProperty("resourceName", discoveryObj.get("name").getAsString());
					resourcePayload.addProperty("ipAddress", discoveryObj.get("ip").getAsString());
					resourcePayload.addProperty("model", discoveryObj.get("model").getAsString());
					resourcePayload.addProperty("moId", discoveryObj.get("uuid").getAsString());
					resourcePayload.addProperty("hostName", discoveryObj.get("host").getAsString());
					resourcePayload.addProperty("nativeType", AppConstants.HOSTS);
					// custom fields
					// set root resource host name and IP address are added to child resources
					resourcePayload.add("tags", rootInfoCustomAttrbts);
					resourcePayload.add(AppConstants.SDK_APP_NAME, rootInfoCustomAttrbts);
					resources.add(resourcePayload);
					
			} 
			LOG.error("DiscoveryProcessorUtil# prepagerResourceDtails# call ended...");
            return resources;
		} catch (Exception e) {
			LOG.error("Failed to prepare prepagerResourceDtails, Reason :" + e.getMessage(), e);
			throw e;
		}
	}

	/**
	 * prepare vm details
	 * 
	 * @param rootInfoCustomAttrbts
	 * @param resources
	 * @param hostMoId
	 * @param nativeAndResourceTypes
	 * @param sourceMoid
	 * @param hostMoid 
	 * @param configurationId 
	 * @param baseUrl 
	 * @param apiTemplate 
	 * @param resourceType 
	 * @return 
	 * @throws Exception 
	 */
	private static List<JsonObject> prepareVmsDetails(APITemplate apiTemplate,String baseUrl,JsonObject rootInfoCustomAttrbts,String configurationId, String resourceType) throws Exception {
		LOG.error("DiscoveryProcessorUtil# prepareVmsDetails# call started...");
		 List<JsonObject> resources =new ArrayList<JsonObject>();

		try {
			String resourceDetails = getResponse(apiTemplate, baseUrl);
			JsonArray discoveryJSON = new Gson().fromJson(resourceDetails, JsonArray.class);
			Map<String,List<String>> relationShipMap = new HashMap<String, List<String>>();

			for (int j = 0; j < discoveryJSON.size(); j++) {
				JsonObject discoveryHostObj = (JsonObject) discoveryJSON.get(j);
				JsonArray discoveryVMObj = discoveryHostObj.getAsJsonArray("vms");
				List<String> listOfVMIds = new ArrayList<String>();
				for (int i = 0; i < discoveryVMObj.size(); i++) {
					JsonObject discover = (JsonObject) discoveryVMObj.get(i);

					JsonObject resourcePayload = new JsonObject();
					resourcePayload.addProperty("resourceType", resourceType);
					resourcePayload.addProperty("resourceName", discover.get("name").getAsString());
					resourcePayload.addProperty("ipAddress", discover.get("ip").getAsString());
					resourcePayload.addProperty("model", discover.get("model").getAsString());
					resourcePayload.addProperty("moId", discover.get("uuid").getAsString());
					resourcePayload.addProperty("hostName", discover.get("host").getAsString());
					resourcePayload.addProperty("nativeType", AppConstants.VMS);
					// custom fields
					// set root resource host name and IP address are added to child resources
					resourcePayload.add("tags", rootInfoCustomAttrbts);
					resourcePayload.add(AppConstants.SDK_APP_NAME, rootInfoCustomAttrbts);
					resources.add(resourcePayload);
					listOfVMIds.add(discover.get("uuid").getAsString());
				}
				LOG.error("DiscoveryProcessorUtil# prepareVmsDetails# listOfVMIds..."+listOfVMIds);

				relationShipMap.put(discoveryHostObj.get("uuid").getAsString(), listOfVMIds);
				LOG.error("DiscoveryProcessorUtil# prepareVmsDetails# relationShipMap..."+relationShipMap);

				InternalCacheSore.getInstance().put(AppConstants.HOSTS,relationShipMap);
			}
			LOG.error("DiscoveryProcessorUtil# prepareVmsDetails# call ended...");

            return resources;
		} catch (Exception e) {
			LOG.error("Failed to prepare Vms Details, Reason :" + e.getMessage(), e);
			throw e;
		}
	}

	/**
	 * @param relationshipArray
	 */
	public static void prepareRelationships(JsonArray relationshipArray) throws Exception {
		LOG.error("DiscoveryProcessorUtil# prepareRelationships# method initiated...");
		try {
		 Map<String, List<String>>  realtionshipData = InternalCacheSore.getInstance().get(AppConstants.HOSTS);
		 realtionshipData.forEach((hostId,listOfVms) -> {
			 listOfVms.forEach((vmId) -> { 
				 JsonObject relationJsonObj = new JsonObject();
				 relationJsonObj.addProperty(AppConstants.RELATION_TYPE, AppConstants.CONNECTED_TO);
				 relationJsonObj.addProperty(AppConstants.SOURCE_MOID, hostId);
				 relationJsonObj.addProperty(AppConstants.TARGET_MOID, vmId);
				 relationshipArray.add(relationJsonObj); 
			 });
		 });
		LOG.error("DiscoveryProcessorUtil# prepareRelationships# method ended...relationshipArray ::{}",relationshipArray);
		}catch (Exception e) {
			LOG.error("Failed to prepare Relationships data, Reason {} {}",e.getMessage(),e);
			throw e;
		} finally {
			//InternalCacheSore.getInstance().removeRelationData(AppConstants.HOSTS);
		}
	}
}