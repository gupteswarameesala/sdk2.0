package com.opsramp.app.processor.monitor;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.opsramp.app.content.util.JsonUtil;
import com.opsramp.app.processor.api.APITemplate;
import com.opsramp.app.processor.monitor.threads.MonitorProcessThread;
import com.opsramp.app.processor.monitor.threads.MonitorProcessThreadPool;
import com.opsramp.app.util.AppConstants;
import com.opsramp.app.util.BaseUtil;

/**
 * Class to process monitoring requests
 * 
 * @author Srini T
 *
 */
public class MonitorDataProcessor {

	private static Logger LOG = org.slf4j.LoggerFactory.getLogger(MonitorDataProcessor.class);
	private JsonObject dataObject = null;
    
	MonitorProcessThreadPool threadPool = new MonitorProcessThreadPool(15);
	/**
	 * @param configurationId
	 * @param monitoringJsonObj
	 * @param gatewayType 
	 */
	public void processMonitoring(String configurationId, JsonObject monitoringJsonObj) {
		try {
			LOG.error("MonitorDataProcessor# processMonitoring# call started.. ");
			LOG.error("MonitorDataProcessor# monitoringJsonObj ::" + monitoringJsonObj.toString());

			JsonObject monitoringConfigPaylaodObj = JsonUtil.getJson(monitoringJsonObj, AppConstants.JSON_PAYLOAD);
			JsonObject discovAppConfigJson = JsonUtil.getJson(monitoringConfigPaylaodObj, "appConfig");
			
			this.dataObject = JsonUtil.getJson(discovAppConfigJson, "data");
			LOG.error("Configuration ID is : {}", configurationId);

			JsonObject nativeTypeObj = JsonUtil.getJson(monitoringConfigPaylaodObj, AppConstants.PAYLOAD_NATIVETYPES);
			Set<String> nativeTypes = nativeTypeObj.keySet();

			// Loading BaseUrls from static file
			JsonObject metricUrlJson = BaseUtil.loadMetricUrls();

			// Get resources Data
			JsonArray resources = monitoringConfigPaylaodObj.get("resources").getAsJsonArray();
			List<JsonObject> metricsPayloadList = null;
			List<Future<Map<String, List<JsonObject>>>> listOfFutures = new ArrayList<>();

			LOG.error("NativeTypes : {}", nativeTypes);
			long sTime = System.currentTimeMillis();
			for (String nativeType : nativeTypes) {
				JsonElement metricsArray = nativeTypeObj.get(nativeType);
				Type metricsType = new TypeToken<Set<String>>() {
				}.getType();
				Set<String> metrics = new Gson().fromJson(metricsArray, metricsType);

				Set<String> metricAPIsList = new TreeSet<String>();

				if (!metricUrlJson.isJsonNull() && metricUrlJson.has(nativeType)) {
					JsonObject nativeMetricUrlJSON = metricUrlJson.get(nativeType).getAsJsonObject();
					JsonArray metricBaseUrls = nativeMetricUrlJSON.get("urls").getAsJsonArray();
					for (JsonElement baseUrlObj : metricBaseUrls) {
						metricAPIsList.add(baseUrlObj.getAsString());
					}
				} else {
					continue;
				}

				LOG.error("metrics : {}", metrics);
				LOG.error("metrics api list : {}", metricAPIsList);
				for (JsonElement resource : resources) {
					JsonObject resourceObj = resource.getAsJsonObject();
					//JsonObject resourcePayload = JsonUtil.getJson(resourceObj, AppConstants.JSON_PAYLOAD);
					JsonObject resourceDetails = JsonUtil.getJson(resourceObj, "resources");

					String resourceId = JsonUtil.getString(resourceDetails, "resourceId");
					String moId = JsonUtil.getString(resourceDetails, "moId");

					LOG.error("resourceId : {}", resourceId);
					LOG.error("moid : {}", moId);

					for (String apiUrl : metricAPIsList) {
						try {
							LOG.error("Get metrics using threads, apiUrl : {}", apiUrl);
							apiUrl = MonitorProcessorUtil.getMetricAPIs(apiUrl, this.dataObject, nativeType);
							if (BaseUtil.useMonitoringThreads()) {
								LOG.error("Get metrics using threads, apiUrl : {}", apiUrl);
								Future<Map<String, List<JsonObject>>> future = threadPool
										.submit(new MonitorProcessThread(this, moId, apiUrl, resourceId, nativeType,
												configurationId, metrics));
								listOfFutures.add(future);
							} else {
								// Prepare Metrics Payload
								LOG.error("Get metrics without threads, apiUrl : {}", apiUrl);
								metricsPayloadList = getMetricsPayload(configurationId, moId, apiUrl, resourceId,
										nativeType, metrics);

								// Publish metrics payload
								if (!metricsPayloadList.isEmpty()) {
									MonitorProcessorUtil.publishMetricPayload(monitoringJsonObj, metricsPayloadList,
											configurationId, resourceId, nativeType);
								}
							}
						} catch (Exception e) {
							LOG.error("Failed to prepare and publish metric data : " + e.getMessage());
						}
					}

					Long publishMsec = System.currentTimeMillis();
					if (BaseUtil.useMonitoringThreads()) { 
						for (Future<Map<String, List<JsonObject>>> future : listOfFutures) {
							try {
								Map<String, List<JsonObject>> moIdMetricListMap = future.get(1L, TimeUnit.SECONDS);
								LOG.error("Future, moIdMetricListMap : {}", moIdMetricListMap);
								if (!moIdMetricListMap.isEmpty()) {
									moIdMetricListMap.entrySet().forEach((moIdMetricList) -> {
										try {
											if (moIdMetricList != null && !moIdMetricList.getValue().isEmpty()) {
												MonitorProcessorUtil.publishMetricPayload(monitoringJsonObj,
														moIdMetricList.getValue(), configurationId, resourceId, nativeType);
											}
										} catch (Exception e) {
											LOG.error("Failed to publishMetricPayload for moId " + moIdMetricList.getKey()
													+ e);
										}
									});
								}
							} catch (Exception e) {
								LOG.error("Failed to publishMetricPayload for moId from future" + e + " with Reason: "
										+ e.getMessage());
								if (BaseUtil.isThrowableExcpetion(e)) {
									throw e;
								}
							}
						}
					}
					LOG.error("MonitorDataProcessor# time taken to publish metricPayloadList {} msec",
							publishMsec - System.currentTimeMillis() + "for nativeType " + nativeType);
				}
			}
			LOG.error("MonitorDataProcessor# processMonitoring# call ended.. ");
			LOG.error("Total time for monitoring :(Sec)" + (System.currentTimeMillis() - sTime) / 1000.0);
		} catch (Exception e) {
			LOG.error("Failed process monitoring for configurationID : {} with error : {} ", configurationId,e.getMessage());
		} finally {
			try {
				LOG.error("Shutting down the ThreadPool Executor when there is an Exception");
				threadPool.getExecutorPool().shutdown();
				threadPool.getExecutorPool().awaitTermination(1000, TimeUnit.MILLISECONDS);
			} catch (Exception e2) {
				LOG.error("Failed to shutdounw the ThreadPool Executor");
			}
		}
	}

	/**
	 * @param configurationId
	 * @param moId
	 * @param apiUrl
	 * @param resourceId
	 * @param nativeType
	 * @param metrics
	 * @return
	 * @throws Exception
	 */
	public List<JsonObject> getMetricsPayload(String configurationId, String moId, String apiUrl, String resourceId,
			String nativeType, Set<String> metrics) throws Exception {

		LOG.error("MonitorDataProcessor# getMetricsPayload# call started ...");

		List<JsonObject> metricsPayloadList = null;
		try {
			APITemplate apiTemplate = APITemplate.getInstance(configurationId);
			apiTemplate.enableRetryAPI(BaseUtil.retryFailedApi());
			metricsPayloadList = MonitorProcessorUtil.getMetricsData(apiTemplate, apiUrl, resourceId, nativeType, moId,
					metrics);

			LOG.error("MonitorDataProcessor# getMetricsPayload# call ended ...");

		} catch (Exception e) {
			throw e;
		}
		return metricsPayloadList;
	}
}