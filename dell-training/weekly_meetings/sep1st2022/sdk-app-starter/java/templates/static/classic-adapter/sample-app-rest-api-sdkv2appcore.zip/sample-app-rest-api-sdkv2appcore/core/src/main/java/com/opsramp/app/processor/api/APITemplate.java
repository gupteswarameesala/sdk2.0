package com.opsramp.app.processor.api;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Map.Entry;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.ws.rs.core.MediaType;
import javax.xml.bind.DatatypeConverter;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpRequestRetryHandler;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.conn.HttpHostConnectException;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HttpContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.opsramp.app.processor.exception.UnauthorizedException;
import com.opsramp.app.util.BaseUtil;

public class APITemplate implements APIConstants {
	
private static Logger logger = LoggerFactory.getLogger(APITemplate.class);
	
	//Basic
    private String apiBaseURI 		= null;
	private String apiUserName 		= null;
	private String apiPassword 		= null;
	private String authType 		= null;
	private DataFormat dataFormat 	= null;
	
	private String apiKey       	= null;
	private String apiSecret    	= null;
	private String accessToken 		= null;
	private OAuthGrantType grantType = null;
	private String apiTokenURL 		= null;
	private int tokenExpiredStatusCode 	= 0;
	
	private static HashMap<String, APITemplate> apiTemplateMap = null;
	
	private boolean isAPIRetryEnable = false;
	
	/** 
	 * @return
	 * @throws Exception
	 */
	public static APITemplate getInstance(String configurationId) throws Exception {
 		if(apiTemplateMap == null) {
			apiTemplateMap = new HashMap<String, APITemplate>();
		}
		if (apiTemplateMap.get(configurationId) == null) {
			apiTemplateMap.put(configurationId, new APITemplate());
		}
		
		return apiTemplateMap.get(configurationId);
	}
	
	/**
	 * Constructor
	 */
	private APITemplate() {
	}
	
	/** GET request 
	 * @param url
	 * @return
	 * @throws Exception 
	 */
	public HttpResponse invokeGET(String url) throws Exception {
		if(logger.isDebugEnabled()) {
			logger.debug("APITemplate# invokeGET# URL: " + url);
		}
		try {
			HttpGet httpMethod = new HttpGet(url);
			setMethodHeaders(httpMethod);
			return handleHttpMethod(httpMethod);
		} catch(Exception e) {
			throw e;
		}
	}
	
	/** GET request with additional headers 
	 * @param url
	 * @param headers
	 * @return HttpResponse
	 * 
	 * @throws Exception
	 */
	public HttpResponse invokeGET(String url, Map<String, String> headers) throws Exception {
		if(logger.isDebugEnabled()) {
			logger.debug("APITemplate# invokeGET# URL : " + url);
		}
		try {
			HttpGet httpMethod = new HttpGet(url);
			setMethodHeaders(httpMethod);
			if(headers != null && !headers.isEmpty()) {
				setAdditionalMethodHeaders(httpMethod, headers);
			}
			return handleHttpMethod(httpMethod);
		} catch(Exception e) {
			throw e;
		}
	}
	
	/** POST request
	 * @param url
	 * @param jsonPayload
	 * @return
	 * @throws Exception
	 */
	public HttpResponse invokePOST(String url, String jsonPayload) throws Exception {
		if(logger.isDebugEnabled()) {
			logger.debug("APITemplate# invokePOST# URL: " + url + ", jsonPayload: " + jsonPayload);
		}
		try {
			if(jsonPayload == null || jsonPayload.isEmpty()) {
				throw new Exception(INVALID_JSON_PAYLOAD);
			}
			HttpPost httpMethod = new HttpPost(url);
			setMethodHeaders(httpMethod);
			HttpEntity entity = new StringEntity(jsonPayload.toString(), UTF_8);
			httpMethod.setEntity(entity);
			return handleHttpMethod(httpMethod);
		} catch(Exception e) {
			throw e;
		}
	}
	
	/** POST request with additional headers
	 * @param url
	 * @param jsonPayload
	 * @return
	 * @throws Exception
	 */
	public HttpResponse invokePOST(String url, String jsonPayload, Map<String, String> headers) throws Exception {
		if(logger.isDebugEnabled()) {
			logger.debug("APITemplate# invokePOST# URL: " + url + ", jsonPayload: " + jsonPayload);
		}
		try {
			if(jsonPayload == null || jsonPayload.isEmpty()) {
				throw new Exception(INVALID_JSON_PAYLOAD);
			}
			HttpPost httpMethod = new HttpPost(url);
			setMethodHeaders(httpMethod);
			if(headers != null && !headers.isEmpty()) {
				setAdditionalMethodHeaders(httpMethod, headers);
			}
			HttpEntity entity = new StringEntity(jsonPayload.toString(), UTF_8);
			httpMethod.setEntity(entity);
			return handleHttpMethod(httpMethod);
		} catch(Exception e) {
			throw e;
		}
	}
	
	/** Method to set Required header Parameters
	 * @param httpMethod
	 */
	private void setMethodHeaders(HttpRequestBase httpMethod) throws Exception {
		setDefaultMethodHeaders(httpMethod);
		logger.debug("setMethodHeaders :started:");
		if (!BaseUtil.isEmpty(this.authType)) {
			switch (this.authType) {
			case AUTH_OAUTH2:
				httpMethod.setHeader(AUTHORIZATION, getAuthorizationHeaderForOauth2());
				break;
			case AUTH_BASIC:
				httpMethod.setHeader(AUTHORIZATION, getAuthorizationHeaderForBasic());
				break;
			case AUTH_NONE:
			default:
				break;
			}
		}
		logger.debug("setMethodHeaders :ended:");
	}

	/** Method to set default headers based on data format
	 * @param httpMethod
	 * @throws Exception
	 */
	private void setDefaultMethodHeaders(HttpRequestBase httpMethod) throws Exception {
		logger.debug("setDefaultMethodHeaders :started:");
		if(this.dataFormat == null || this.dataFormat == DataFormat.JSON) {
			if (httpMethod instanceof HttpPost || httpMethod instanceof HttpPut) {
				httpMethod.setHeader(CONTENT_TYPE, MediaType.APPLICATION_JSON);
			}
			httpMethod.setHeader(ACCEPT, MediaType.APPLICATION_JSON);
			logger.debug("setDefaultMethodHeaders :ended:");
		}
	}
	
	/** Method to encode the userName and Password to Base64 format
	 * @return
	 */
	private String getAuthorizationHeaderForBasic() throws Exception {
		String token = this.apiUserName + COLON + this.apiPassword;
		 try {
			 return BASIC_STR + DatatypeConverter.printBase64Binary(token.getBytes(UTF_8));
		 } catch (Exception ex) {
			 throw new IllegalStateException(BASIC_AUTH_ERROR, ex);
		 }
	}

	/** Set Basic authentication details
	 * @param apiUserName
	 * @param apiPassword
	 * @throws Exception
	 */
	public void setBasicAuthentication(String apiUserName, String apiPassword) throws Exception {
		if(apiUserName == null || apiUserName.isEmpty()) {
			throw new Exception(INVALID_API_USERNAME);
		}
		if(apiPassword == null || apiPassword.isEmpty()) {
			throw new Exception(INVALID_API_PAWWORD);
		}
		
		this.authType = AUTH_BASIC;
		this.apiUserName = apiUserName;
		this.apiPassword =apiPassword;
	}
	
	/** Set additional headers
	 * @param httpMethod
	 * @param headers
	 * @throws Exception
	 */
	private void setAdditionalMethodHeaders(HttpRequestBase httpMethod, Map<String, String> headers) throws Exception {
		if(httpMethod == null ) {
			return;
		}
		if(headers == null || headers.isEmpty()) {
			return;
		}
		
		for(Entry<String, String> header : headers.entrySet()) {
			httpMethod.removeHeaders(header.getKey());
			httpMethod.setHeader(header.getKey(), header.getValue());
		}
	}
	
	/** Set Oauth2 authentication details. 
	 * If granType is 'client_credentials' then apiKey, apiSecret are mandatory. 
	 * If granType is 'password' then apiKey, apiSecret, apiUserName and apiPassword are mandatory
	 * @param apiKey
	 * @param apiSecret
	 * @throws Exception
	 */
	public void setOauth2Authentication(OAuthGrantType grantType, String apiKey, String apiSecret, String apiUserName, String apiPassword, String apiTokenURL, int tokenExpiredStatusCode) throws Exception {

		if(grantType == null) {
			throw new UnauthorizedException(INVALID_GRANT_TYPE);
		}
		if (grantType == OAuthGrantType.PASSWORD || grantType == OAuthGrantType.CLIENT_CREDENTIALS) {
			if(apiKey == null || apiKey.isEmpty()) {
				throw new UnauthorizedException(INVALID_API_KEY);
			}
			if(apiSecret == null || apiSecret.isEmpty()) {
				throw new UnauthorizedException(INVALID_API_SECRET);
			}
		}
		if(grantType == OAuthGrantType.PASSWORD || grantType == OAuthGrantType.JWT) {
			if(apiUserName == null || apiUserName.isEmpty()) {
				throw new UnauthorizedException(INVALID_API_USERNAME);
			}
			if(apiPassword == null || apiPassword.isEmpty()) {
				throw new UnauthorizedException(INVALID_API_PAWWORD);
			}
		}
		
		if(apiTokenURL == null) {
			throw new UnauthorizedException(INVALID_API_TOKEN_URL);
		}
		
		this.authType = AUTH_OAUTH2;
		this.apiKey = apiKey;
		this.apiSecret = apiSecret;
		this.grantType = grantType;
		this.apiUserName = apiUserName;
		this.apiPassword = apiPassword;
		this.apiTokenURL = apiTokenURL;
		this.tokenExpiredStatusCode = tokenExpiredStatusCode;
		
	}
	
	/** Method to generate accessToken using apiKey and apiSecret
	 * @return
	 */
	private String getAuthorizationHeaderForOauth2() throws Exception {
		if(this.accessToken == null || this.accessToken.isEmpty()) {
			generateAccessToken();
		}
		return BEARER + this.accessToken;
	}
	
	/** Method to generated Access Token for OAUTH
	 * @return
	 */
	private void generateAccessToken() throws Exception {
		if(logger.isDebugEnabled()) {
			logger.debug("APITemplate# generateAccessToken# call initiated.. ");
		}
		Map<String, Object> map = new HashMap<String,Object>();
		HttpResponse response = null;
		String accessTokenBodyJSONStr = null;
		try {
			//preparing required body to generate access token
			List<BasicNameValuePair> parametersBody = new ArrayList<BasicNameValuePair>();
			parametersBody.add(new BasicNameValuePair(GRANT_TYPE, this.grantType.name().toLowerCase()));
			if (this.grantType == OAuthGrantType.PASSWORD || this.grantType == OAuthGrantType.CLIENT_CREDENTIALS) {
				parametersBody.add(new BasicNameValuePair(CLIENT_ID, this.apiKey));
				parametersBody.add(new BasicNameValuePair(CLIENT_SECRET, this.apiSecret));
			}
			if (this.grantType == OAuthGrantType.PASSWORD || this.grantType == OAuthGrantType.JWT) {
				parametersBody.add(new BasicNameValuePair(OAUTH2_USER_NAME, this.apiUserName));
				parametersBody.add(new BasicNameValuePair(OAUTH2_PASSWORD, this.apiPassword));
			}
			
			HttpPost httpMethod = new HttpPost(this.apiTokenURL);
			httpMethod.setEntity(new UrlEncodedFormEntity(parametersBody, UTF_8));
			response = handleHttpMethod(httpMethod);
			if (response != null) {
				accessTokenBodyJSONStr = APIUtil.getResponseBody(response,"");
			}
			if(response.getStatusLine().getStatusCode() != HttpStatus.SC_OK) {
				if(response.getStatusLine().getStatusCode() != HttpStatus.SC_FORBIDDEN || response.getStatusLine().getStatusCode() != HttpStatus.SC_UNAUTHORIZED) {
					throw new UnauthorizedException(accessTokenBodyJSONStr);
				}
				else
				{
	        	throw new Exception(accessTokenBodyJSONStr);
				}
	        } else {
	        	ObjectMapper mapper = new ObjectMapper();
		        map = mapper.readValue(accessTokenBodyJSONStr, new TypeReference<HashMap<String, Object>>() {});
		        this.accessToken = (String) map.get(ACCESS_TOKEN);
	        }
			if(logger.isDebugEnabled()) {
				logger.debug("APITemplate# generateAccessToken# call ended.. ");
			}
		} catch(Exception e) {
			logger.error("APITemplate# generateAccessToken# Unable to Generate Access Tocken, Reason : "+e.getMessage(),e);
			throw e;
		}
	}
	
	/** Handle HttpRequest with return response as HttpResponse object
	 * @param httpMethod
	 * @throws Exception
	 */
	private HttpResponse handleHttpMethod(HttpRequestBase httpMethod) throws Exception {
		if(logger.isDebugEnabled()) {
			logger.debug("APITemplate# handleHttpMethod# call initiated.. ");
		}
		CloseableHttpClient httpclient = null;
		HttpResponse httpResponse = null;
		try {
			httpclient = getCloseableHttpClient();
			//trustSelfSignedSSL();
			httpResponse = httpclient.execute(httpMethod);
			
			// Retry the accessToken if request failed due to expired access token
			if(!BaseUtil.isEmpty(this.authType) && this.authType.equals(AUTH_OAUTH2) && httpResponse != null && httpResponse.getStatusLine().getStatusCode() == this.tokenExpiredStatusCode) {
				generateAccessToken();
				httpMethod.removeHeaders(AUTHORIZATION);
				httpMethod.setHeader(AUTHORIZATION, BEARER + this.accessToken);
				//To avoid looping , regenerating the token only once using below boolean
				httpResponse = handleHttpMethod(httpMethod);
			}
			if(logger.isDebugEnabled()) {
				logger.debug("APITemplate# handleHttpMethod# call ended.. ");
			}
			return httpResponse;
		} catch(Exception e) {
			logger.error("APITemplate# handleHttpMethod# Failed to execute Http method, Reason :"+e.getMessage(),e);
			throw e;
		} finally {
			//httpclient.close();
		} 
	}
	
	/**
	 * @return
	 */
	public CloseableHttpClient getCloseableHttpClient() throws Exception {
		CloseableHttpClient httpclient = null;
		try {
			SSLContext sslContext = SSLContext.getInstance("TLSv1.2"); //TLS
			sslContext.init(null, getTrustCerts(), new SecureRandom());

			HttpClientBuilder builder = HttpClientBuilder.create();
			httpclient = builder.build();
			RequestConfig config = RequestConfig.custom()
					.setConnectTimeout(CONNECTION_TIME_OUT)
					.setConnectionRequestTimeout(CONNECTION_TIME_OUT)
					.setSocketTimeout(CONNECTION_TIME_OUT)
					.build();
			if(isAPIRetryEnable) {	
				builder.setRetryHandler(new HttpRequestRetryHandler() {
					   @Override
					    public boolean retryRequest(IOException exception, int executionCount, HttpContext context) {
					        if (executionCount > 1) {
					        	logger.error("Maximum tries reached for client http pool {}",executionCount);
					            return false;
					        }
					        if (exception instanceof ConnectTimeoutException || exception instanceof HttpHostConnectException) {
					        	if(logger.isDebugEnabled()) {
					        		logger.debug("No response from server on call number" + executionCount);
					        	}
					        	return true; 
						 }
					     return false;
					   }
			    });
			}
			builder.setDefaultRequestConfig(config).build();

			SSLConnectionSocketFactory ssf = new SSLConnectionSocketFactory(sslContext, NoopHostnameVerifier.INSTANCE);
			Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
					.register(HTTPS_PROTOCOL, ssf)
					.register(HTTP_PROTOCOL, new PlainConnectionSocketFactory())
					.build();

			PoolingHttpClientConnectionManager ccm = new PoolingHttpClientConnectionManager(registry);
			httpclient = builder.setConnectionManager(ccm).build();
		} catch (Exception e) {
			throw e;
		} catch (Throwable t) {
			throw t;
		}
		return httpclient;
	}
	
	/**
	 * @return
	 */
	public TrustManager[ ] getTrustCerts() throws Exception {

		TrustManager[ ] trustCerts = new TrustManager[ ] {
				new X509TrustManager() {
					@Override
					public X509Certificate[] getAcceptedIssuers() {
						return null;
					}
					@Override
					public void checkServerTrusted(X509Certificate[] chain, String authType)
							throws CertificateException {
					}
					@Override
					public void checkClientTrusted(X509Certificate[] chain, String authType)
							throws CertificateException {
					}
				}
		};
		return trustCerts;
	}
	
	/**
	 * 
	 */
	protected static void trustSelfSignedSSL() throws Exception {
		try {
			TrustManager[ ] trustCerts = new TrustManager[ ] {
		            new X509TrustManager() {
						@Override
						public X509Certificate[] getAcceptedIssuers() {
							return null;
						}
						@Override
						public void checkServerTrusted(X509Certificate[] chain, String authType)
								throws CertificateException {
						}
						@Override
						public void checkClientTrusted(X509Certificate[] chain, String authType)
								throws CertificateException {
						}
					}
		    };
			
			HostnameVerifier hostnameVerifier = new HostnameVerifier() {
				@Override
				public boolean verify(String hostname, SSLSession session) {
					return true;
				}
	        };
			
		    SSLContext sslContext = null;
	    	sslContext = SSLContext.getInstance("TLSv1.2");
	    	sslContext.init(null, trustCerts, new SecureRandom());
		    HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
		    HttpsURLConnection.setDefaultHostnameVerifier(hostnameVerifier);
		    
	    } catch (GeneralSecurityException ex) {
	    	throw ex;
	    }  catch (Throwable t) {
			throw t;
		}
	}
	

	/**
	 * @return apiBaseURI
	 */
	public String getApiBaseURI() {
		return apiBaseURI;
	}

	/**
	 * @param apiBaseURI
	 */
	public void setApiBaseURI(String apiBaseURI) {
		this.apiBaseURI = apiBaseURI;
	}
	
	/**
	 * @param apiUserName the apiUserName to set
	 */
	public void setApiUserName(String apiUserName) {
		this.apiUserName = apiUserName;
	}

	/**
	 * @param apiPassword the apiPassword to set
	 */
	public void setApiPassword(String apiPassword) {
		this.apiPassword = apiPassword;
	}

	/**
	 * @param authType the authType to set
	 */
	public void setAuthType(String authType) {
		this.authType = authType;
	}

	/**
	 * @param dataFormat the dataFormat to set
	 */
	public void setDataFormat(DataFormat dataFormat) {
		this.dataFormat = dataFormat;
	}
	
	public void enableRetryAPI(Boolean isRetry) {
		this.isAPIRetryEnable = isRetry;
	}
	
}
