package com.opsramp.app.util;


import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;
import java.util.Map;
import java.util.Properties;

import org.apache.http.conn.HttpHostConnectException;
import org.slf4j.Logger;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.opsramp.app.processor.exception.UnauthorizedException;

/**
 * @author Srini T
 *
 */
public class BaseUtil {

	static Logger logger = org.slf4j.LoggerFactory.getLogger(BaseUtil.class);

	private static Properties properties;
	public static JsonObject metricUrlJson;

	static {
		properties = new Properties();
		try {
			metricUrlJson = readDataAsJSONFromFile(AppConstants.METRIC_URL_JSON);
			properties
					.load(new FileInputStream(MessageFormat.format(AppConstants.FILE_PATH, AppConstants.SDK_APP_NAME)));
		} catch (Exception e) {
			logger.error("Failed to load the property : {} ", e.getMessage());
		}
	}

	/**
	 * @return
	 */
	public static boolean readFromFile() {
		if (!BaseUtil.isEmpty(System.getenv(AppConstants.READ_FROM_FILE))) {
			return Boolean.parseBoolean(System.getenv(AppConstants.READ_FROM_FILE));
		} else if (!BaseUtil.isEmpty(properties.getProperty(AppConstants.READ_FILE))) {
			return Boolean.parseBoolean(properties.getProperty(AppConstants.READ_FILE));
		}
		return false;
	}

	/**
	 * Read data from file and send it as JSON object converted
	 * 
	 * @param jsonFileName
	 * @return
	 * @throws Exception
	 */
	public static JsonObject readDataAsJSONFromFile(String fileName) throws Exception {
		//return new JsonObject(readDataAsStringFromFile(fileName));
		return new Gson().fromJson(readDataAsStringFromFile(fileName), JsonObject.class);
	}

	/**
	 * Read data from file and send it as String
	 * 
	 * @param jsonFileName
	 * @return
	 * @throws Exception
	 */
	public static String readDataAsStringFromFile(String fileName) throws Exception {
		StringBuilder resourceInfoObj = new StringBuilder();

		InputStream inputStream = BaseUtil.class.getClassLoader().getResourceAsStream(fileName);
		InputStreamReader streamReader = new InputStreamReader(inputStream, StandardCharsets.UTF_8);
		BufferedReader reader = new BufferedReader(streamReader);
		for (String line; (line = reader.readLine()) != null;) {
			resourceInfoObj.append(line);
		}
		return resourceInfoObj.toString();
	}

	/**
	 * @return
	 */
	public static boolean retryFailedApi() {
		if (!BaseUtil.isEmpty(System.getenv(AppConstants.RETRY_FAILED_API))) {
			return Boolean.parseBoolean(System.getenv(AppConstants.READ_FROM_FILE));
		} else if (!BaseUtil.isEmpty(properties.getProperty(AppConstants.RETRY_FAILED_API))) {
			return Boolean.parseBoolean(properties.getProperty(AppConstants.RETRY_FAILED_API));
		}
		return false;
	}

	public static JsonObject loadMetricUrls() {
		// TODO Auto-generated method stub
		return metricUrlJson;
	}
	
	/*
	 * Metric Data Prepare
	 */
	public static JsonObject metricsCloudFormatConveter(String metricName, String instanceName, String instanceValue, JsonObject tags) {

		long timestamp = java.time.Instant.now().getEpochSecond();

		JsonObject metricData = new JsonObject();
		metricData.addProperty("metricName",metricName);
		metricData.addProperty("instanceName",instanceName);
		metricData.addProperty("instanceVal",instanceValue);
		metricData.addProperty("ts",String.valueOf(timestamp));
		metricData.add("labels",tags);

		return metricData;
	}
	
	/**
	 * Method to check given string null or empty
	 * 
	 * @param param
	 * @return
	 */
	public static boolean isEmpty(String param) {
		return param == null || AppConstants.EMPTY_STRING.equals(param.trim()) || AppConstants.NULL_STRING.equals(param.trim());
	}
	
	public static boolean isThrowableExcpetion(Exception e) {
		if (logger.isDebugEnabled()) {
			logger.debug("Exception details : {}", e.getClass());
		}
		if (e instanceof HttpHostConnectException
				|| e instanceof UnauthorizedException || e instanceof UnknownHostException) {
			return true;
		}
		return false;
	}
	
	/**
	 * @return
	 * @throws Exception
	 */
	public static boolean useMonitoringThreads() throws Exception {
		return true;
	}
	
}
