package com.opsramp.app.processor.monitor;

import java.lang.reflect.Type;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;

import com.fasterxml.uuid.Generators;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.opsramp.app.util.AppConstants;
import com.opsramp.app.util.BaseUtil;
import com.opsramp.app.content.core.alerthandler.AlertData;
import com.opsramp.app.content.core.alerthandler.AlertUtils;
import com.opsramp.app.content.core.alerthandler.MetricResponse;
import com.opsramp.app.content.core.alerthandler.ResourceMetricData;
import com.opsramp.app.content.core.integration.ServiceFactory;
import com.opsramp.app.content.util.JsonUtil;


public class AlertsDataProcessUtil {

	static Logger logger = org.slf4j.LoggerFactory.getLogger(AlertsDataProcessUtil.class);

	/**
	 * It process and publish the metrics and alerts
	 * 
	 * @param configId
	 * @param metricDef
	 * @param monitorjsonStr
	 * @param resourceType
	 */
	public static void publishMetricsAndAlert(String configId, String metricDef, String monitorjsonStr,
			String resourceType) {

		logger.error("AlertsDataProcessUtil# publishMetricsAndAlert configId gppp : " + configId);
		logger.error("AlertsDataProcessUtil# publishMetricsAndAlert payload : " + metricDef);
		logger.error("AlertsDataProcessUtil# publishMetricsAndAlert monitorjsonStr : " + monitorjsonStr);
		logger.error("AlertsDataProcessUtil# publishMetricsAndAlert resourceType : " + resourceType);

		Gson gson = new Gson();
		var jsonElement = gson.fromJson(metricDef, JsonElement.class);
		JsonObject monitoringJsonObj = jsonElement.getAsJsonObject();
		JsonObject monitoringConfigPaylaodObj = JsonUtil.getJson(monitoringJsonObj, AppConstants.JSON_PAYLOAD);

		String templateId = JsonUtil.getString(monitoringConfigPaylaodObj, "templateId");
		String monitorId = JsonUtil.getString(monitoringConfigPaylaodObj, "monitorId");
		logger.error("templateId : {}", templateId);
		logger.error("monitorId : {}", monitorId);

		try {
			JsonObject genericPayload = new Gson().fromJson(monitorjsonStr, JsonObject.class);

			JsonObject metricPayload = genericPayload.get("payload").getAsJsonObject();
			Type userListType = new TypeToken<Set<JsonObject>>() {
			}.getType();

			Set<JsonObject> metricDataList = gson.fromJson(metricPayload.get("data").getAsJsonArray(), userListType);
			// Set<JsonObject> metricDataList = metricPayload.get("data").getAsJsonArray();

			logger.error("AlertsDataProcessUtil# publishMetricsAndAlert metricDataList : " + metricDataList);

			Map<String, Object> metricMap = processAlertsData(configId, metricDataList,
					metricPayload.get("id").getAsString(), resourceType, templateId, monitorId);

			@SuppressWarnings("unchecked")
			Set<JsonObject> finalMetricData = (Set<JsonObject>) metricMap.get(AppConstants.FINAL_METRIC_DATA);

			@SuppressWarnings("unchecked")
			List<MetricResponse> metricResponseList = (List<MetricResponse>) metricMap
					.get(AppConstants.METRIC_RESPONSE_LIST);

				logger.error(
						"AlertsDataProcessUtil# publishMetricsAndAlert finalMetricData from AlertUtil prepared : " + finalMetricData);
				logger.error("AlertsDataProcessUtil# publishMetricsAndAlert  metricResponseList prepared : "
						+ metricResponseList);

			// publish metrics
			publishMetrics(genericPayload, metricPayload, finalMetricData);

			// publish alerts Data
			publishAlertsMetrics(genericPayload, metricResponseList);
			if (logger.isDebugEnabled()) {
				logger.debug("AlertsDataProcessUtil# publishMetricsAndAlert Publish Monitor Metrics Ended.");
			}
		} catch (Exception e) {
			logger.error("Failed to publish metrics : " + e.getMessage() + " error : " + e);
		}

	}

	/**
	 * @param genericRequest
	 * @param metricResponseList
	 */
	public static void publishAlertsMetrics(JsonObject genericPayload, List<MetricResponse> metricResponseList) {
			logger.error("AlertsDataProcessUtil# publishAlertsMetrics started.");
		// Resource publish
		for (MetricResponse metricResponse : metricResponseList) {
			AlertData alertData = metricResponse.getAlertData();
			if (alertData != null) {

				JsonObject cloudAlertResponse = new JsonObject();

				cloudAlertResponse.addProperty("version", AppConstants.VERSION);
				UUID generate = Generators.timeBasedGenerator().generate();
				cloudAlertResponse.addProperty("id", generate.toString());
				cloudAlertResponse.addProperty("profile", genericPayload.get("profile").getAsString());
				cloudAlertResponse.addProperty("gateway", genericPayload.get("gateway").getAsString());
				cloudAlertResponse.addProperty("collector", AppConstants.COLLECTOR);
				cloudAlertResponse.addProperty("app", genericPayload.get("app").getAsString());
				cloudAlertResponse.addProperty("appId", genericPayload.get("appId").getAsString());
				cloudAlertResponse.addProperty("module", "");
				cloudAlertResponse.addProperty("type", AppConstants.ALERT_TYPE);
				cloudAlertResponse.addProperty("subType", "");
				cloudAlertResponse.addProperty("action", AppConstants.ACTION);

				Gson gson = new Gson();
				String alertDataPayloadString = gson.toJson(alertData);
				JsonObject alertPayloadObj = gson.fromJson(alertDataPayloadString, JsonObject.class);
				cloudAlertResponse.add("payload", alertPayloadObj);

				Timestamp timestampmills1 = new Timestamp(System.currentTimeMillis());
				Instant instant1 = timestampmills1.toInstant();
				cloudAlertResponse.addProperty("timestamp", instant1.toString());
				// String cloudAlertResponseString = new Gson().toJson(cloudAlertResponse);

					logger.error("AlertsDataProcessUtil# publishAlertsMetrics Final Cloud Monitor Alert Payload -- :",
							cloudAlertResponse.toString());
				try {
					ServiceFactory.getMessagePublisher().publish(cloudAlertResponse.toString());
						logger.error(
								"AlertsDataProcessUtil# publishAlertsMetrics Monitor Alert Request processed successfully");
				} catch (Exception e) {
					logger.error("Failed to process metric alerts, Reason : " + e.getMessage());
				}
			}
		}
		if (logger.isDebugEnabled()) {
			logger.debug("MonitorDataProcessor# publishAlertsMetrics Ended.");
		}
	}

	/**
	 * process the alert data
	 * 
	 * @param configId
	 * @param metricDataList
	 * @param resourceId
	 * @param resourceType
	 * @param monitorId
	 * @param templateId
	 * @return
	 */
	public static Map<String, Object> processAlertsData(String configId, Set<JsonObject> metricDataList,
			String resourceId, String resourceType, String templateId, String monitorId) {
			logger.error("AlertsDataProcessUtil# publishMetricsAndAlert Alerts metrics filter started");
			logger.error("ResourceType : {}", resourceType);
			logger.error("Resource UUID :{}", resourceId);
		Map<String, Object> metricMap = new ConcurrentHashMap<String, Object>();
		try {
			Set<JsonObject> finalyMetricData = new HashSet<JsonObject>();
			List<ResourceMetricData> metricResourceData = new ArrayList<ResourceMetricData>();
			for (JsonObject responsePayload : metricDataList) {
				if (BaseUtil.isEmpty(responsePayload.get("instanceName").getAsString())
						|| BaseUtil.isEmpty(responsePayload.get("instanceVal").getAsString())
						|| BaseUtil.isEmpty(responsePayload.get("metricName").getAsString())) {
					if (true) {
						logger.debug("Received null/empty data in MetricData with metricName:"
								+ responsePayload.get("metricName").getAsString() + ",InstanceName:"
								+ responsePayload.get("instanceName").getAsString() + ",InstanceVal"
								+ responsePayload.get("instanceVal").getAsString());
					}
					continue;
				}

				ResourceMetricData resourceMetricData = new ResourceMetricData();
				resourceMetricData.setInstanceName(responsePayload.get("instanceName").getAsString());
				resourceMetricData.setInstanceVal(responsePayload.get("instanceVal").getAsString());
				resourceMetricData.setMetricName(responsePayload.get("metricName").getAsString());
				resourceMetricData.setTs(Long.parseLong(responsePayload.get("ts").getAsString()));
				metricResourceData.add(resourceMetricData);
			}

			List<MetricResponse> metricResponseList = null;
			try {
				AlertUtils.publishAlerts(templateId, monitorId, resourceType, resourceId,
						metricResourceData);
				//ServiceFactory.getMessagePublisher().publishAlerts(resourceId, resourceType, templateId, monitorId, metricResourceData);
				//ServiceFactory.getMessagePublisher().publishMetrics(resourceId, resourceType, templateId, monitorId);
				//metricResponseList = AlertUtils.metricProcessor(templateId, monitorId, resourceType, resourceId,
                        //metricResourceData);
			} catch (Exception e1) {
					logger.error("Unable To Parse Metric Response List : {}", e1);
			}

				logger.error("Metrics after APPUTIL : {}", metricResponseList);
				logger.error("Metrics after metricResponseList size : {}", metricResponseList.size());

			long timestamp = java.time.Instant.now().getEpochSecond();
			if (metricResponseList != null) {
				for (MetricResponse metricResponse : metricResponseList) {
					logger.error("Metrics after metricResponse.getMetricData() size : {}", metricResponse.getMetricData());
					if (metricResponse.getMetricData() != null) {
						JsonObject responsePayload = new JsonObject();
						responsePayload.addProperty("instanceName", metricResponse.getMetricData().getInstanceName());
						responsePayload.addProperty("instanceVal", metricResponse.getMetricData().getMetricValue());
						responsePayload.addProperty("metricName", metricResponse.getMetricData().getMetricId());
						responsePayload.addProperty("ts", String.valueOf(timestamp));
						finalyMetricData.add(responsePayload);
					}
				}
				metricMap.put("finalMetricData", finalyMetricData);
				metricMap.put("metricResponseList", metricResponseList);
			}
				logger.error("MetricData List {} ", finalyMetricData);
				logger.error("metricResponse List {} ", metricResponseList);
				logger.error("Alerts metrics filter completed");
		} catch (Exception e) {
			logger.error("Failed to process alert data : " + e.getMessage());
		}
		return metricMap;
	}

	/**
	 * publish metrics for cluster gateway
	 * 
	 * @param genericPayload
	 * @param metricPayload
	 * @param finalMetricData
	 */
	public static void publishMetrics(JsonObject genericPayload, JsonObject metricPayload,
			Set<JsonObject> finalMetricData) {
		// Prepare metric Payload with metric data prepared
		JsonObject payloadEntity = new JsonObject();
		String metricsDataJson = new Gson().toJson(finalMetricData);
		JsonArray metricsDataJsonData = new Gson().fromJson(metricsDataJson, JsonArray.class);
		payloadEntity.add("data", metricsDataJsonData);
		payloadEntity.addProperty("id", metricPayload.get("id").getAsString());

		genericPayload.add("payload", payloadEntity);

		Timestamp timestampmills = new Timestamp(System.currentTimeMillis());
		Instant instant = timestampmills.toInstant();
		genericPayload.addProperty("timestamp", instant.toString());

		// ObjectMapper objectMapper = new ObjectMapper();
		String mertricMonitorJsonStr = null;
		try {
			if (genericPayload != null) {
				mertricMonitorJsonStr = genericPayload.toString();// objectMapper.writeValueAsString(genericPayload);
			}
		} catch (Exception e) {
			logger.error("Monitor object string exception : " + e.getMessage(), e);
		}
			logger.error("AlertsDataProcessUtil# publishMetrics# Final Cloud Monitor Metrics Payload -- : " + mertricMonitorJsonStr);
		try {
			// publish metrics
			ServiceFactory.getMessagePublisher().publish(mertricMonitorJsonStr);
			logger.error("AlertsDataProcessUtil# publishMetrics# publish Monitor Request processed successfully");
		} catch (Exception e) {
			logger.error("Failed to publish metrics, Reason : " + e.getMessage());
		}
	}

}