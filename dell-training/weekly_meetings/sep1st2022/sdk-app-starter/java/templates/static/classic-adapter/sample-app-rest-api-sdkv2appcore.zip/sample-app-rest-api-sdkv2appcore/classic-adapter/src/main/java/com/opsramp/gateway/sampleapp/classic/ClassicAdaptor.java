package com.opsramp.gateway.sampleapp.classic;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.opsramp.app.content.core.alerthandler.MetricResponse;
import com.opsramp.app.content.core.alerthandler.ResourceMetricData;
import com.opsramp.app.content.core.integration.CacheStore;
import com.opsramp.app.content.core.integration.MessagePublisher;
import com.opsramp.app.content.core.integration.ServiceFactory;
import com.opsramp.app.processor.discovery.DiscoveryDataProcessor;
import com.opsramp.app.processor.monitor.MonitorDataProcessor;
import com.opsramp.app.util.AppConstants;
import com.opsramp.app.util.BaseUtil;
import com.opsramp.app.content.util.JsonUtil;
import com.opsramp.gateway.content.core.DatastoreClient;
import com.opsramp.gateway.content.core.CloudMessagePublisher;
import com.opsramp.gateway.content.core.Content;


public class ClassicAdaptor implements Content {
    private static final Logger LOG = LoggerFactory.getLogger(ClassicAdaptor.class);

    private static final String APP_NAME = "virtual-vcenters";

    public void init() {
    	LOG.error(" Invoking ClassicAdapter Init ");
    	final Content app = this;
    	
    	CacheStore cacheStore = new CacheStore() {

			@Override
			public String get(String store, String key) throws Exception {
				return DatastoreClient.get(app, store, key);
			}

			@Override
			public String gget(String store, String key) throws Exception {
				return DatastoreClient.get(app, store, key);
			}

			@Override
			public boolean put(String store, String key, String value) throws Exception {
				return DatastoreClient.put(app, store, key, value);
			}

			@Override
			public boolean remove(String store, String key) throws Exception {
				return DatastoreClient.remove(app, store, key);
			}

    	};
    	
        MessagePublisher publisher = new MessagePublisher() {
            @Override
            public void publish(String message) throws Exception {
                CloudMessagePublisher.publish(message);
            }

            @Override
            public void publish(String topic, String message) throws Exception {
                CloudMessagePublisher.publish(message);
            }

            @Override
            public void publishMetrics(String configId, String metricDef, String message, String resourceType) throws Exception {
                CloudMessagePublisher.publishMetrics(configId, metricDef, message);
            }

			@Override
			public List<MetricResponse> publishAlerts(String templateId, String monitorId, String resourceType, String resourceId, List<ResourceMetricData> metricData) throws Exception {
				return null;
				//return CloudMessagePublisher.publishAlerts(templateId, monitorId, resourceType, resourceId, metricData);
			}

            
        };

        ServiceFactory.init(cacheStore, publisher);
        LOG.error("Initiation of cachestore and publisher starting  CacheStore {} , Publisher{} , app{} " , cacheStore , publisher , app.getName());
    }

    public String getName() {
        return APP_NAME;
    }

	public void messageRecived(String cloudToGatewayMessage) {
		try {
			LOG.error("CloudToGatewayMessage =>  Messsage: {}", cloudToGatewayMessage);
			JsonObject cloudToGatewayMessageObject = new Gson().fromJson(cloudToGatewayMessage, JsonObject.class);
			if (cloudToGatewayMessageObject.get("module") != null
					&& !BaseUtil.isEmpty(cloudToGatewayMessageObject.get("module").getAsString())) {
				if (cloudToGatewayMessageObject.get("module").getAsString().equalsIgnoreCase(AppConstants.DISCOVERY)) {
					LOG.error("CloudToGatewayMessage Discovery Gopi =>  Messsage: {}", cloudToGatewayMessage);

					DiscoveryDataProcessor discoveryDataProcessor = new DiscoveryDataProcessor();
					discoveryDataProcessor.processDiscovery(cloudToGatewayMessageObject);
				}
			} else {
				JsonObject appConfigJson = JsonUtil.getJson(cloudToGatewayMessageObject, "appConfig");
				String configurationId = JsonUtil.getString(appConfigJson, "configurationId");
				
				LOG.error("configurationId Monitoring Gopi =>  configurationId: {}, appConfigJson {} ", configurationId  , appConfigJson);
				LOG.error("CloudToGatewayMessage Monitoring Gopi =>  Messsage: {}", cloudToGatewayMessage);

				MonitorDataProcessor monitorDataProcessor = new MonitorDataProcessor();
				monitorDataProcessor.processMonitoring(configurationId, cloudToGatewayMessageObject);
			}
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
		}
	}
}