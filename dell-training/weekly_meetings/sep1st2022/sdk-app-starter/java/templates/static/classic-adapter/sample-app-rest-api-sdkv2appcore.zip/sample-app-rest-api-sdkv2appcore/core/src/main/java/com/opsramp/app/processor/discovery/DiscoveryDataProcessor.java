package com.opsramp.app.processor.discovery;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.opsramp.app.processor.api.APITemplate;
import com.opsramp.app.processor.exception.NoDataFoundException;
import com.opsramp.app.util.AppConstants;
import com.opsramp.app.util.BaseUtil;
import com.opsramp.app.content.core.integration.ResourceFilter;
import com.opsramp.app.content.util.JsonUtil;
import com.opsramp.app.content.util.credential.AppCredentialUtil;

/**
 * Class to process discovery requests
 * 
 * @author Srini T
 *
 */
public class DiscoveryDataProcessor {

	private static Logger LOG = LoggerFactory.getLogger(DiscoveryDataProcessor.class);
	private JsonObject payloadObject = null;
	private String configurationId = null;

	/**
	 * @param discoveryJsonObj
	 * @throws Exception
	 */
	public void processDiscovery(JsonObject discoveryJsonObj) throws Exception {

		LOG.error("DiscoveryDataProcessor# processDiscovery# call Initiating... ");
		try {
			long startTime = System.currentTimeMillis();

			this.payloadObject = JsonUtil.getJson(discoveryJsonObj, AppConstants.JSON_PAYLOAD);
			this.configurationId = JsonUtil.getString(discoveryJsonObj, AppConstants.PAYLOAD_CONFIG_ID);
			JsonObject dataObject = JsonUtil.getJson(this.payloadObject, "data");
			if (dataObject.get("credential") != null) {
				JsonArray credentialArray = dataObject.get("credential").getAsJsonArray();
				if (!credentialArray.isEmpty()) {
					LOG.error("credentialArray ::" + credentialArray.toString());
					for(int i=0; i< credentialArray.size();i++) {
					JsonObject credentialObj = credentialArray.get(i).getAsJsonObject();
					JsonObject credentialValueDataObj = credentialObj.get("credentialValue").getAsJsonObject()
							.get("data").getAsJsonObject();
					String credKey = credentialValueDataObj.get("key1").getAsString();
					String cipherTxt = credentialValueDataObj.get("cipher").getAsString();
					byte[] appCredentialUtil = AppCredentialUtil.decryptCredential(credKey, cipherTxt);
					String appCredentialValues = new String(appCredentialUtil);
					LOG.error("appCredentialValues ::" + appCredentialValues);
					}
				}
			}
			processAndPublishResourcePayload(discoveryJsonObj);
			LOG.error("To complete total discovery (processDiscovery)  (Sec) : "
					+ (System.currentTimeMillis() - startTime) / 1000.0);
			LOG.error("DiscoveryDataProcessor# processDiscovery# call Ended... ");
		} catch (Exception e) {
			LOG.error("Failed to process the discovery for configuration ID : " + configurationId + " with reason : "
					+ e.getMessage());
			throw new Exception("Failed to process the discovery for configuration ID : " + configurationId);
		}
	}

	/**
	 * @param discoveryJsonObj
	 * @throws Exception
	 */
	private void processAndPublishResourcePayload(JsonObject discoveryJsonObj)
			throws Exception {
		LOG.error("DiscoveryDataProcessor# processAndPublishResourcePayload# call started ...");
		List<JsonObject> resources = null;
		JsonArray relationshipArray = new JsonArray();
		try {
			// Discovery API request
			long startTime = System.currentTimeMillis();
			JsonObject nativeTypesObj = this.payloadObject.get("nativeTypes").getAsJsonObject();

			Set<String> nativeTypes = nativeTypesObj.keySet();
			LOG.error("List of nativeTypes to discover : " + nativeTypes);
            int resourcesCount =0; 
			for (String nativeType : nativeTypes) {
				String resourceType = nativeTypesObj.get(nativeType).getAsJsonObject().get("resourceType")
						.getAsString();
				resources = getDiscoveryData(discoveryJsonObj, nativeType, resourceType);

				LOG.error("Time taken to prepare the resources (Sec): "
						+ (System.currentTimeMillis() - startTime) / 1000.0);
				if (resources == null || resources.isEmpty()) {
					throw new NoDataFoundException(
							"Resources payload list received empty/null. Hence not proceeding with publishing ");
				} else {
					resourcesCount = resourcesCount + resources.size();
				}
				// Publish resources data
				long sTime = System.currentTimeMillis();
				boolean response = publishDiscoveryPayload(discoveryJsonObj, resources, nativeType);
				LOG.error(
						"Time taken to publish the resources (Sec): " + (System.currentTimeMillis() - sTime) / 1000.0);
				if (response) {
					LOG.error("Discovery process request success with configurationId :" + this.configurationId);
				}
			}
			LOG.error("Total discovered resources count : " + resourcesCount);
			// publish relationships data
			long sTime1 = System.currentTimeMillis();
			DiscoveryProcessorUtil.prepareRelationships(relationshipArray);
			if (relationshipArray != null && !relationshipArray.isJsonNull()) {
			DiscoveryProcessorUtil.publishRelationshipsToCloud(discoveryJsonObj, relationshipArray);
			}
			LOG.error(
					"Time taken to publish the relationships (Sec): " + (System.currentTimeMillis() - sTime1) / 1000.0);
		} catch (Exception e) {
			LOG.error("Failed to get discovery data for configurationId : " + this.configurationId + "  ,Reason: "
					+ e.getMessage(), e);
			throw new Exception("Failed to get discovery data from APIServices, Reason: " + e.getMessage(), e);
		}

		LOG.error("DiscoveryDataProcessor# getResourcePayloadList# call ended ...");
	}

	/**
	 * @param discoveryJsonObj
	 * @param nativeAndResourceTypes
	 * @param discoveryJsonObj 
	 * @param nativeType 
	 * @return
	 * @throws Exception
	 */
	private List<JsonObject> getDiscoveryData(JsonObject discoveryJsonObj,String nativeType, String resourceType)
			throws Exception {

		List<JsonObject> resources = null;
		LOG.error(" DiscoveryDataProcessor# getDiscoveryData# call initiating ...");

		// 2 - Get discovery data
		try {
			APITemplate apiTemplate = APITemplate.getInstance(this.configurationId);
			resources = DiscoveryProcessorUtil.getResources(this.configurationId, apiTemplate, this.payloadObject,
					discoveryJsonObj,nativeType,resourceType);
			LOG.error(" DiscoveryDataProcessor# getDiscoveryData# call ended...");
		} catch (Exception e) {
			LOG.error("Failed to process DiscoveryDataProcessor# getDiscoveryData() with configurationId :"
					+ this.configurationId + "with error:" + e.getMessage() + e);
			throw e;
		}
		return resources;
	}

	/**
	 * @param discoveryJsonObj
	 * @param resourcesPayloadList
	 * @param nativeType2 
	 * @return
	 * @throws Exception
	 */
	private boolean publishDiscoveryPayload(JsonObject discoveryJsonObj, List<JsonObject> resourcesPayloadList, String nativeType)
			throws Exception {

		LOG.error("DiscoveryDataProcessor# publishDiscoveryPayload# method started..for ConfigurationId :"
				+ this.configurationId);
		try {
		//ResourceFilter
		String messageId = JsonUtil.getString(discoveryJsonObj,"messageId");
		ResourceFilter resourceFilter = new ResourceFilter(messageId, configurationId, nativeType,resourcesPayloadList);
		List<JsonObject> listOfResourceWithFilters =resourceFilter.filter();
		LOG.error("listOfResourceFilters  is : {}", listOfResourceWithFilters.toString());
		
		String currentMoIds = null;
		List<String> allCurrentMoIdsList = new ArrayList<String>();
		
			if (listOfResourceWithFilters == null || listOfResourceWithFilters.isEmpty()) {
				throw new NoDataFoundException("Resource Payload list is empty to publish discovery payload");
			}
			for (JsonObject resourcePayload : listOfResourceWithFilters) {
				try {
					if (this.configurationId != null && resourcePayload.get("moId") != null) {
						allCurrentMoIdsList.add(resourcePayload.get("moId").getAsString());
						if (BaseUtil.isEmpty(currentMoIds)) {
							currentMoIds = resourcePayload.get("moId").getAsString();
						} else {
							currentMoIds += AppConstants.COMMMA + resourcePayload.get("moId").getAsString();
						}
						//String nativeType = resourcePayload.get("nativeType").getAsString();
						String storeMoIdStr = resourcePayload.get("moId").getAsString();
						LOG.error("nativeType ::" + nativeType + "   storeMoIdStr ::" + storeMoIdStr);
					}
				} catch (Exception e) {
					LOG.error("Unable Store ConfigurationId in configStore,configName {} " + ", configId {} "
							+ this.configurationId + e.getMessage() + e);
				}
				// Generate HashCode for each and every resources and store into appStore,
				if (!DiscoveryProcessorUtil.isResourcePublishRequired(resourcePayload, this.configurationId)) {
					continue;
				}
				// Publish Resource Payloads
				DiscoveryProcessorUtil.publishResourceToCloud(discoveryJsonObj, resourcePayload);
			}
			LOG.error("DiscoveryDataProcessor# publishDiscoveryPayload# method ended..");

		} catch (Exception e) {
			LOG.error("Unable to Process publishDiscoveryPayload with configurationId :" + this.configurationId
					+ " Reason:" + e.getMessage());
		}
		return true;
	}

}