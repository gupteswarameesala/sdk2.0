package com.opsramp.app.processor.api;

/**
 * @author gopi
 *
 */
public enum OAuthGrantType {
	//Do not change the enums - these are w.r.to. OAuth standards
		//Used in assigning authorized grant types for generated API key pairs.

		CLIENT_CREDENTIALS("Client Credentials"),

		PASSWORD("Password Credentials"),

		//REFRESH_TOKEN("Refresh Token"),

		JWT("JSON Web Token");

		private String name;

		public static OAuthGrantType parse(String name) {
			if(name != null) {
				return OAuthGrantType.valueOf(name.toUpperCase());
			}
			return null;
		}

		OAuthGrantType(String name) {
			this.name = name;
		}

		public String getName() {
			return name;
		}

}
