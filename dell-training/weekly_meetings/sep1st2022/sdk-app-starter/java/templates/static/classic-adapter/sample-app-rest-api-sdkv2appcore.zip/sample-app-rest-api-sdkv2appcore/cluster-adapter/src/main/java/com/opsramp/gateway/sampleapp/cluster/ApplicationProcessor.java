package com.opsramp.gateway.sampleapp.cluster;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.opsramp.app.content.core.actionhandler.AbstractActionHandler;
import com.opsramp.app.content.core.actionhandler.ActionRegistry;
import com.opsramp.app.content.core.actionhandler.ConfigurationCache;
import com.opsramp.app.content.core.actionhandler.ConfigurationLoader;
import com.opsramp.app.content.core.alert.NativeTypeMetricLoader;
import com.opsramp.app.content.core.integration.FilteredResourceRegistry;
import com.opsramp.gateway.common.core.GenericResponse;
import com.opsramp.gateway.common.listener.Processor;
import com.opsramp.gateway.utils.JsonUtil;

public class ApplicationProcessor implements Processor{
	private static final Logger LOG = LoggerFactory.getLogger(ApplicationProcessor.class);

	private static final String ACTION = "action";
	private static final String MESSAGE_ID = "messageId";
	private static final String MODULE = "module";
	private static final String SUBTYPE = "subtype";

	@Override
	public GenericResponse run(String queueName, String request) {
		//CloudToGatewayRequest cloudToGatewayRequest = new Gson().fromJson(request, CloudToGatewayRequest.class);

		/*if (cloudToGatewayRequest != null 
				&& cloudToGatewayRequest.getAction() != null
				&& !cloudToGatewayRequest.getAction().isBlank()) {*/
		var jsonElement = new Gson().fromJson(request, JsonElement.class);
		var jsonObj = jsonElement.getAsJsonObject();

		var module = JsonUtil.getString(jsonObj, MODULE);
		var subType = JsonUtil.getString(jsonObj, SUBTYPE);
		var action = JsonUtil.getString(jsonObj, ACTION);
		var messageUuid = JsonUtil.getString(jsonObj, MESSAGE_ID);
		
		// Ignoring Ack Message as part of SDK v2, Need to review with team and clear this message from cloud
		if(action.equalsIgnoreCase("ACK")) {
			return new GenericResponse(JsonUtil.getString(jsonObj, "id"), GenericResponse.OK);
		}

		AbstractActionHandler handler = null;
		try {
			handler = getActionHandler(module, subType, action, request);
			if(handler == null) {
				LOG.error("Handler not found for Module:{}, SubType:{}, Action:{}", module,subType,action);
				return new GenericResponse(messageUuid, GenericResponse.ERROR);
			}
			if (handler != null) {
				handler.perform();
				return new GenericResponse(messageUuid, GenericResponse.OK);
			} 
		}catch (Exception e) {
			e.printStackTrace();
			LOG.error("{} {}", e, e.getMessage());
			LOG.error("Exception in handler Module:{}, SubType:{}, Action:{}", module,subType,action);
			return new GenericResponse(messageUuid, GenericResponse.ERROR);
		} finally {
			if(handler != null) {
				handler.destroy();
				if(module.equalsIgnoreCase("Discovery") && subType.equalsIgnoreCase("Configuration") && action.equalsIgnoreCase("Update")) {
					FilteredResourceRegistry.getInstance().remove(messageUuid);
				}
			}
		}
		//}

		//should replace null object
		return new GenericResponse(messageUuid, GenericResponse.OK);
	}

	private AbstractActionHandler getActionHandler(String module, String subType, String action, String cloudToGatewayReq) throws Exception{
		var handler = String.format("%s-%s-%s", module, subType, action);

		LOG.info("Recieved app message------------:{}, {}", handler, cloudToGatewayReq);
		Class<? extends AbstractActionHandler> handlerClass = ActionRegistry.getHandler(handler);
		AbstractActionHandler handlerObject = handlerClass.getDeclaredConstructor().newInstance();

		if(module.equalsIgnoreCase("Monitoring") && subType.equalsIgnoreCase("Configuration") && action.equalsIgnoreCase("Update")) {
			var jsonElement = new Gson().fromJson(cloudToGatewayReq, JsonElement.class);
			var jsonObj = jsonElement.getAsJsonObject();

			LOG.info("Monitoring message recieved------------------------------------:{}", jsonElement.toString());

			JsonObject payloadObject = JsonUtil.getJson(jsonObj, "payload");

			String templateID = JsonUtil.getString(payloadObject, "templateId");
			String templateShaValue = JsonUtil.getString(payloadObject, "templateShaValue");
			String monitorId = JsonUtil.getString(payloadObject, "monitorId");

			String templateObject = ConfigurationLoader.load(ConfigurationCache.MONITORING, templateID, templateShaValue);
			var templateJsonElement= new Gson().fromJson(templateObject, JsonElement.class);

			//Construct App Monitoring Request
			String monitoringPayload = constructAppMonitoringRequest(jsonObj, templateID, monitorId, templateJsonElement);
			handlerObject.setRequestContext(monitoringPayload);

			// Load Alert Definitions
			NativeTypeMetricLoader.getInstance().loadMetricConfiguration(templateID, monitorId, templateShaValue, templateJsonElement);

		}else if(module.equalsIgnoreCase("Discovery") && subType.equalsIgnoreCase("Configuration") && action.equalsIgnoreCase("Update")) {
			LOG.info("Discovery message recieved------------------------------------:{}", cloudToGatewayReq);
			handlerObject.setRequestContext(injectCredentialObject(cloudToGatewayReq));
		}

		return handlerObject;
	}

	private String constructAppMonitoringRequest(JsonObject jsonObj,
			String templateID, String monitorId, JsonElement templateJsonElement) {
		
		JsonObject payloadObject = JsonUtil.getJson(jsonObj, "payload");
		
		JsonArray newResourceJsonArray = new JsonArray();

		JsonElement appConfigRequestElement = JsonUtil.getElement(payloadObject, "appConfig");
		var appConfigRequestJsonObject = appConfigRequestElement.getAsJsonObject();

		String resourceAppConfigId = JsonUtil.getString(appConfigRequestJsonObject, "appConfigId");
		String resourceAppConfigIdShaValue = JsonUtil.getString(appConfigRequestJsonObject, "appConfigShaValue");

		Map<String,String> resourceAppConfigCredentialMap = new HashMap<String,String>();

		JsonElement resourceAppConfigCredentialElement = JsonUtil.getElement(appConfigRequestJsonObject, "credential");
		if(resourceAppConfigCredentialElement != null) {
			JsonArray resourceAppConfigCredentialJsonArray = resourceAppConfigCredentialElement.getAsJsonArray();
			if(resourceAppConfigCredentialJsonArray != null && resourceAppConfigCredentialJsonArray.size() > 0) {
				for(JsonElement resourceAppConfigCredential : resourceAppConfigCredentialJsonArray) {
					JsonObject resourceAppConfigCredentialJsonObject = resourceAppConfigCredential.getAsJsonObject();
					resourceAppConfigCredentialMap.put(JsonUtil.getString(resourceAppConfigCredentialJsonObject, "credentialId"),JsonUtil.getString(resourceAppConfigCredentialJsonObject, "shaValue"));
				}
			}
		}

		// Loading Discovery Configuration with Credentials
		String discoveryConfigurationObj = ConfigurationLoader.load(ConfigurationCache.DISCOVERY, resourceAppConfigId, resourceAppConfigIdShaValue);
		JsonObject discoveryConfigurationJsonObject = null;
		if(discoveryConfigurationObj != null) {
			var discoveryConfigurationElement = new Gson().fromJson(discoveryConfigurationObj, JsonElement.class);
			discoveryConfigurationJsonObject = discoveryConfigurationElement.getAsJsonObject();

			JsonObject dbDiscoveryConfigurationPayloadJsonObject = JsonUtil.getJson(discoveryConfigurationJsonObject, "payload");
			JsonObject discoveryConfigurationDataJsonObject = JsonUtil.getJson(dbDiscoveryConfigurationPayloadJsonObject, "data");
			JsonElement credentialElement = JsonUtil.getElement(discoveryConfigurationDataJsonObject, "credentialId");

			if(credentialElement != null) {
				JsonArray newCredentialJsonArray = new JsonArray();

				JsonArray credentialJsonArray = credentialElement.getAsJsonArray();
				if(credentialJsonArray != null && credentialJsonArray.size() > 0) {
					for(JsonElement credentialArray : credentialJsonArray) {
						String credentialId = credentialArray.getAsString();

						JsonObject newCredentialJsonObject = new JsonObject();
						newCredentialJsonObject.addProperty("credentialId", credentialId);

						String credentialConfigurationObj = ConfigurationLoader.load(ConfigurationCache.CREDENTIAL, credentialId, resourceAppConfigCredentialMap.get(credentialId));
						if(credentialConfigurationObj != null) {
							var newcredentialConfigurationObjElement = new Gson().fromJson(credentialConfigurationObj, JsonElement.class);
							var newcredentialConfigurationJsonObj = newcredentialConfigurationObjElement.getAsJsonObject();
							newCredentialJsonObject.add("credentialValue", JsonUtil.getJson(newcredentialConfigurationJsonObj, "payload"));
						}
						newCredentialJsonArray.add(newCredentialJsonObject);
					}
				}
				discoveryConfigurationDataJsonObject.remove("credentialId");
				discoveryConfigurationDataJsonObject.add("credential", newCredentialJsonArray);
			}
		}

		// Loading Resource Objects
		JsonElement resourceElement = JsonUtil.getElement(payloadObject, "resources");

		if(resourceElement != null) {
			JsonArray resourceArrayJson = resourceElement.getAsJsonArray();
			if(resourceArrayJson != null && resourceArrayJson.size() > 0) {
				for(JsonElement resourceArray : resourceArrayJson) {

					JsonObject resourceJsonObject = resourceArray.getAsJsonObject();
					String resourceId = JsonUtil.getString(resourceJsonObject, "resourceId");
					String resourceShaValue = JsonUtil.getString(resourceJsonObject, "resourceShaValue");

					// Scheduler Resource Credential Payload
					Map<String,String> resourceCredentialMap = new HashMap<String,String>();
					JsonElement resourceCredentialElement = JsonUtil.getElement(resourceJsonObject, "credential");
					if(resourceCredentialElement != null) {
						JsonArray resourceCredentialJsonArray = resourceCredentialElement.getAsJsonArray();
						if(resourceCredentialJsonArray != null && resourceCredentialJsonArray.size() > 0) {
							for(JsonElement resourceCredential : resourceCredentialJsonArray) {
								JsonObject resourceCredentialJsonObject = resourceCredential.getAsJsonObject();
								resourceCredentialMap.put(JsonUtil.getString(resourceCredentialJsonObject, "credentialId"),JsonUtil.getString(resourceCredentialJsonObject, "shaValue"));
							}
						}
					}

					String resourceObject = ConfigurationLoader.load(ConfigurationCache.RESOURCE, resourceId, resourceShaValue);

					if(resourceObject != null) {
						var resourceObjectElement = new Gson().fromJson(resourceObject, JsonElement.class);
						var resourceDbJsonObject = resourceObjectElement.getAsJsonObject();

						JsonObject dbPayloadObject = JsonUtil.getJson(resourceDbJsonObject, "payload");
						JsonObject dbResourcesObject = JsonUtil.getJson(dbPayloadObject, "resources");
						// Loading Resource Credentials
						JsonElement dbResourceCredentialElement = JsonUtil.getElement(dbResourcesObject, "credentialId");

						if(dbResourceCredentialElement != null) {
							JsonArray newResourceCredentialJsonArray = new JsonArray();

							JsonArray dbResourceCredentialJsonArray = dbResourceCredentialElement.getAsJsonArray();
							if(dbResourceCredentialJsonArray != null && dbResourceCredentialJsonArray.size() > 0) {
								for(JsonElement dbCredentialArray : dbResourceCredentialJsonArray) {
									String credentialId = dbCredentialArray.getAsString();

									JsonObject newResourceCredentialJsonObject = new JsonObject();
									newResourceCredentialJsonObject.addProperty("credentialId", credentialId);

									String resourceCredentialConfigurationObj = ConfigurationLoader.load(ConfigurationCache.CREDENTIAL, credentialId, resourceCredentialMap.get(credentialId));
									if(resourceCredentialConfigurationObj != null) {
										var newResourceCredentialConfigurationObjElement = new Gson().fromJson(resourceCredentialConfigurationObj, JsonElement.class);
										var newResourceCredentialConfigurationJsonObj = newResourceCredentialConfigurationObjElement.getAsJsonObject();
										newResourceCredentialJsonObject.add("credentialValue",JsonUtil.getJson(newResourceCredentialConfigurationJsonObj, "payload"));
									}
									newResourceCredentialJsonArray.add(newResourceCredentialJsonObject);
								}
							}
							dbResourcesObject.remove("credentialId");
							dbResourcesObject.add("credential", newResourceCredentialJsonArray);
						}
						//newResourceJsonArray.add(resourceDbJsonObject);
						newResourceJsonArray.add(dbPayloadObject);
					}
				}
			}
		}

		var templateJsonObject = templateJsonElement.getAsJsonObject();
		var templatePayloadObject = JsonUtil.getJson(templateJsonObject, "payload");

		String nativeType = JsonUtil.getString(templatePayloadObject, "nativeType");

		JsonArray metricJsonArray = new JsonArray();

		var monitorObject = JsonUtil.getJson(templatePayloadObject, "monitors");
		if(monitorObject != null) {
			Set<Map.Entry<String, JsonElement>> monitors = monitorObject.entrySet();
			if(monitors != null && monitors.size() > 0) {
				for (Map.Entry<String, JsonElement> monitor : monitors) {
					//String monitorName = monitor.getKey();
					JsonElement monitorValue = monitor.getValue();
					var monitorJsonObject = monitorValue.getAsJsonObject();

					String monId = JsonUtil.getString(monitorJsonObject, "uuid");
					if(monitorId.equalsIgnoreCase(monId)) {
						JsonObject metricsJsonObject = JsonUtil.getJson(monitorJsonObject, "metrics");

						Set<Map.Entry<String, JsonElement>> metrics = metricsJsonObject.entrySet();
						for (Map.Entry<String, JsonElement> metric : metrics) {
							metricJsonArray.add(metric.getKey());
						}
					}
				}
			}
		}

		JsonObject appRequestObject = new JsonObject();
		
		appRequestObject.addProperty("messageId", JsonUtil.getString(jsonObj, "messageId"));
		appRequestObject.addProperty(MODULE, JsonUtil.getString(jsonObj, MODULE));
		appRequestObject.addProperty(SUBTYPE, JsonUtil.getString(jsonObj, SUBTYPE));
		appRequestObject.addProperty(ACTION, JsonUtil.getString(jsonObj, ACTION));
		appRequestObject.addProperty("appIntegrationId", JsonUtil.getString(discoveryConfigurationJsonObject, "appIntegrationId"));
		appRequestObject.addProperty("configurationId", JsonUtil.getString(discoveryConfigurationJsonObject, "configurationId"));
		appRequestObject.addProperty("configurationName", JsonUtil.getString(discoveryConfigurationJsonObject, "configurationName"));		
		appRequestObject.addProperty("managementProfileId", JsonUtil.getString(discoveryConfigurationJsonObject, "managementProfileId"));	
		
		JsonObject appRequestPayloadObject = new JsonObject();
		
		appRequestPayloadObject.add("template", templateJsonElement);
		appRequestPayloadObject.addProperty("templateId", templateID);
		appRequestPayloadObject.addProperty("monitorId", monitorId);
		appRequestPayloadObject.add("appConfig", JsonUtil.getJson(discoveryConfigurationJsonObject, "payload"));

		JsonObject nativeTypeObjectValue = new JsonObject();
		nativeTypeObjectValue.add(nativeType, metricJsonArray);

		appRequestPayloadObject.add("nativeType", nativeTypeObjectValue);
		appRequestPayloadObject.add("resources", newResourceJsonArray);
		
		appRequestObject.add("payload", appRequestPayloadObject);
		

		return appRequestObject.toString();
	}

	private String injectCredentialObject(String cloudToGatewayReq) {
		var jsonElement = new Gson().fromJson(cloudToGatewayReq, JsonElement.class);
		var jsonObj = jsonElement.getAsJsonObject();
		
		String configurationId = JsonUtil.getString(jsonObj, "configurationId");
		String sha = JsonUtil.getString(jsonObj, "sha");
		ConfigurationLoader.load(ConfigurationCache.DISCOVERY, configurationId, sha);

		JsonObject payloadObject = JsonUtil.getJson(jsonObj, "payload");
		var dataObj = JsonUtil.getJson(payloadObject, "data");

		JsonElement credentialIdElement = JsonUtil.getElement(dataObj, "credential");
		if(credentialIdElement != null) {
			JsonArray modifiedCredential = new JsonArray();

			JsonArray credentialArray = credentialIdElement.getAsJsonArray();
			if(credentialArray != null && credentialArray.size() > 0) {
				for(JsonElement credentialArr : credentialArray) {
					JsonObject credentialJsonObject = credentialArr.getAsJsonObject();
					String credentialId = JsonUtil.getString(credentialJsonObject, "credentialId");
					String shaValue = JsonUtil.getString(credentialJsonObject, "shaValue");

					String dbCredentialObject = ConfigurationLoader.load(ConfigurationCache.CREDENTIAL, credentialId, shaValue);
					var dbCredentialJsonElement = new Gson().fromJson(dbCredentialObject, JsonElement.class);
					var dbCredentialJsonObject = dbCredentialJsonElement.getAsJsonObject();

					JsonObject newCredentialJsonObject = new JsonObject();
					newCredentialJsonObject.addProperty("credentialId", credentialId);
					newCredentialJsonObject.add("credentialValue", JsonUtil.getJson(dbCredentialJsonObject, "payload"));

					modifiedCredential.add(newCredentialJsonObject);
				}
			}
			if(modifiedCredential != null && modifiedCredential.size() > 0) {
				dataObj.remove("credentialId");
				dataObj.add("credential", modifiedCredential);
			}
		}

		return jsonElement.toString();
	}

}
