package com.opsramp.app.processor.api;

/**
 * ENUM class about response format
 * @author Srini T
 */
public enum DataFormat {

	CSV("csv"),
	JSON("json");

	private String name;

	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	DataFormat(String name) {
		this.name = name;
	}

	public static DataFormat parse(String name) {
		if(name != null) {
			return DataFormat.valueOf(name.toUpperCase());
		}
		return null;
	}
}