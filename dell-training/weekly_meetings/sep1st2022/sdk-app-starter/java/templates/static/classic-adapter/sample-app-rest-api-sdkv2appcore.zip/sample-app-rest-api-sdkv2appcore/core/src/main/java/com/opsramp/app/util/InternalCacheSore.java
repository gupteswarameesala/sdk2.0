package com.opsramp.app.util;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class InternalCacheSore {

	private static volatile InternalCacheSore instance = null;
	
	private InternalCacheSore() {
		if (instance != null) {
			throw new IllegalStateException(
					"Only one instance can be created for this class - " + InternalCacheSore.class.getName());

		}
	}
	
	public static InternalCacheSore getInstance() {
		if (instance == null) {
			synchronized (InternalCacheSore.class) {
				if (instance == null) {
					instance = new InternalCacheSore();
				}
			}
		}
		return instance;
	}

	private Map<String,Map<String, List<String>>> cacheStore = loadFromCacheOnStartUp();

	private Map<String, Map<String, List<String>>> loadFromCacheOnStartUp() {
		return new ConcurrentHashMap<>();
	}

	public void put(String key, Map<String, List<String>> value) {
		cacheStore.put(key, value);
	}
	
	public Map<String, List<String>> get(String key) {
		return cacheStore.get(key);
	}
	
	public void remove(String key) {
		cacheStore.remove(key);
	}

}