package com.opsramp.app.processor.monitor.threads;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonObject;
import com.opsramp.app.processor.monitor.MonitorDataProcessor;
//import com.opsramp.app.util.BaseUtil;

public class MonitorProcessThread implements Callable<Map<String,List<JsonObject>>> {
	private static Logger logger = LoggerFactory.getLogger(MonitorProcessThread.class);

	private MonitorDataProcessor apiService = null;
	private String moId = null;
	private String apiURL = null;
	private String configurationId = null;
	private String resourceId = null;
	private String nativeType = null;
	private Set<String> metrics = null;

	public MonitorProcessThread(MonitorDataProcessor apiService, String moId, String apiURL,
			String resourceId, String nativeType, String configurationId, Set<String> metrics) {
		this.apiService = apiService;
		this.moId = moId;
		this.apiURL = apiURL;
		this.resourceId = resourceId;
		this.nativeType = nativeType;
		this.configurationId = configurationId;
		this.metrics = metrics;
	}

	@Override
	public Map<String, List<JsonObject>> call() throws Exception {
		List<JsonObject> metricsPayloadList = null;
		Map<String, List<JsonObject>> metricsMaps = new HashMap<>();
		try {
			if (logger.isDebugEnabled()) {
				logger.debug("------------------------------");
				logger.debug("MonitorProcessorThread started for thread " + Thread.currentThread().getName()
						+ " for nativeType " + nativeType);
				logger.debug("MonitorProcessorThread started for apiUrl :: " + apiURL + " , moId " + moId);
				logger.debug("------------------------------");
			}
			// Prepare Metrics Payload
			metricsPayloadList = this.apiService.getMetricsPayload(configurationId,moId, apiURL, resourceId,
					nativeType,metrics);
			metricsMaps.put(moId, metricsPayloadList);

		} catch (Exception e) {
			logger.error("Error while preparing metrics list payload and publish, reason: " + e);
			throw e;
		} finally {
			if (logger.isDebugEnabled()) {
				logger.debug("MonitorProcessorThread ended for thread " + Thread.currentThread().getName()
						+ " for nativeType " + nativeType);
				logger.debug("MonitorProcessorThread ended for apiUrl :: " + apiURL + " , moId " + moId);
			}
		}
		return metricsMaps;
	}
}
