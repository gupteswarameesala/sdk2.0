package com.opsramp.gateway.sampleapp.cluster.handler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.opsramp.app.content.core.actionhandler.AbstractActionHandler;
import com.opsramp.app.content.util.JsonUtil;
import com.opsramp.app.processor.discovery.DiscoveryDataProcessor;
import com.opsramp.app.processor.exception.NoDataFoundException;
import com.opsramp.app.util.AppConstants;



public class DiscoveryHandler extends AbstractActionHandler {

	private static final Logger LOG = LoggerFactory.getLogger(DiscoveryHandler.class);

	@Override
	public void perform() {
		LOG.error("Inside DiscoveryHandler..!! Received discovery request payload from Cluster Gateway..!!");
		JsonObject discoveryJsonObj = null;
		try {
			if(this.requestContext.getRequest() == null) { 
				throw new NoDataFoundException("Request Context Should not be null or empty");
			}
			DiscoveryDataProcessor discoveryDataProcessor = new DiscoveryDataProcessor();
			var jsonElement = new Gson().fromJson((String) this.requestContext.getRequest(), JsonElement.class);
			discoveryJsonObj = jsonElement.getAsJsonObject();
			LOG.error("discoveryJsonObj  is : {}", discoveryJsonObj.toString());
            //process Discovery Request
			discoveryDataProcessor.processDiscovery(discoveryJsonObj);
		} catch (Exception e) {
			LOG.error("Failed to process the discovery request for configuration Id : {} with error : {} ", e.getMessage(), 
					JsonUtil.getString(discoveryJsonObj, AppConstants.PAYLOAD_CONFIG_ID));
		}
	}

}
