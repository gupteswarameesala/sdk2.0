package com.opsramp.app.processor.api;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.opsramp.app.processor.exception.UnauthorizedException;
import com.opsramp.app.processor.exception.UnknownException;
import com.opsramp.app.util.BaseUtil;

/**
 * @author Srini T
 *
 */
public class APIUtil implements APIConstants {
	
	private static Logger logger = LoggerFactory.getLogger(APIUtil.class);
	private static List<Integer> sucessStatuses = Arrays.asList(HttpStatus.SC_OK, HttpStatus.SC_ACCEPTED, HttpStatus.SC_CREATED, HttpStatus.SC_PARTIAL_CONTENT);
	
	/** Method to find whether given http response status is 200 series or not
	 * 
	 * @param statusCode
	 * @return
	 */
	public static boolean isRequestSucceeded(HttpResponse response) {
		return sucessStatuses.contains(response.getStatusLine().getStatusCode());
	}
	
	/** Parse the status message response
	 * 
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public static String getResponseBody(HttpResponse response,String del) throws Exception {
		String responseBody = null;
		try {
			if(BaseUtil.isEmpty(del)) {
				del = EMPTY_STRING;
			}
			InputStream in = response.getEntity().getContent();
			BufferedReader reader = new BufferedReader(new InputStreamReader(in));
			StringBuilder sb = new StringBuilder();
			String line = null;
			while ((line = reader.readLine()) != null) {
				sb.append(line + del);
			}
			responseBody = sb.toString();
			//if the response gets succeeded returning the response body
			if(isRequestSucceeded(response)) {
				return responseBody;
			}
			//if the status code is not 200 series generating new Exception based on status code
			int statusCode = response.getStatusLine().getStatusCode();
			if (statusCode == HttpStatus.SC_UNAUTHORIZED || statusCode == HttpStatus.SC_FORBIDDEN) {
				throw new UnauthorizedException(statusCode+HYPHEN+responseBody);
			} else {
				throw new UnknownException(statusCode+HYPHEN+responseBody);
			}
		} catch(Exception e) {
			logger.error("APIUtil# getResponseBody# Unable to get response body, Reason :{}"+e.getMessage(),e);
			throw e;
		}
	}
	
	/** Parse the status message response
	 * 
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public static String getResponseBody(HttpResponse response) throws Exception {
		String responseBody = null;
		try {
			InputStream in = response.getEntity().getContent();
			BufferedReader reader = new BufferedReader(new InputStreamReader(in));
			StringBuilder sb = new StringBuilder();
			String line = null;
			while ((line = reader.readLine()) != null) {
				sb.append(line);
			}
			responseBody = sb.toString();
			//if the response gets succeeded returning the response body
			if(isRequestSucceeded(response)) {
				return responseBody;
			}
			//if the status code is not 200 series generating new Exception based on status code
			int statusCode = response.getStatusLine().getStatusCode();
			if (statusCode == HttpStatus.SC_UNAUTHORIZED || statusCode == HttpStatus.SC_FORBIDDEN) {
				throw new UnauthorizedException(statusCode+HYPHEN+responseBody);
			} else {
				throw new UnknownException(statusCode+HYPHEN+responseBody);
			} 
		} catch(Exception e) {
			logger.error("APIUtil# getResponseBody# Unable to get response body, Reason :{}"+e.getMessage(),e);
			throw e;
		}
	}
	
	 /**
	 * @param responseMap
	 * @return
	 */
	public static String getResponseStatusCode(HashMap<String, Object> responseMap) {
		  return (String)responseMap.get(STATUS);
	  }
	
}