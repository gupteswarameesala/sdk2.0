package com.opsramp.app.processor.monitor.threads;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonObject;

public class MonitorProcessThreadPool {
	private static Logger logger = LoggerFactory.getLogger(MonitorProcessThreadPool.class);

	public ExecutorService pool = null;

	public MonitorProcessThreadPool(int noOfThreads) {
		this.pool = Executors.newFixedThreadPool(noOfThreads);
	}

	public ExecutorService getExecutorPool() {
		return this.pool;
	}

	public Future<Map<String, List<JsonObject>>> submit(MonitorProcessThread processThread) {
		Future<Map<String, List<JsonObject>>> future = null;
		try {
			future = pool.submit(processThread);
			logger.debug("Submitted to thread ");
		} catch (Throwable e) {
			logger.error("Failed to submit to thread Reason is : " + e.getMessage());
			throw e;
		}
		return future;
	}
}
