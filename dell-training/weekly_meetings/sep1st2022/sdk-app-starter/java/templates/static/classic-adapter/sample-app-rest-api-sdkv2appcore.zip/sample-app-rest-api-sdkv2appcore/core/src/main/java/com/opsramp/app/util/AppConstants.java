package com.opsramp.app.util;

public final class AppConstants {
	
	public static final String SDK_APP_NAME 				= "virtual-vcenters";
	public static final String MONITORING 					= "MONITORING";
	public static final String DISCOVERY 					= "DISCOVERY";
	public static final String ACK 							= "ACK";
	
	public static final String RELATIONSHIP_TYPE	        = "RELATIONSHIP";
	public static final String RELATION_ACTION	            = "CREATE";
	public static final String MD5                          = "MD5";

	public static final String RESOURCETYPES 				= "resourceTypes";
	public static final String METRICS 						= "metrics";
	public static final String CREDENTIAL 					= "Credential";
	public static final String ITEMS 						= "items";

	public static final String APIVERSION 					= "apiVersion";

	public static final String VERSION 						= "1.0.0";
	public static final String COLLECTOR 					= "GATEWAY";
	public static final String MONITOR_TYPE 				= "METRIC";
	public static final String ACTION 						= "POST";

	public static final String ALERT_TYPE 					= "ALERT";
	public static final String DNS_NAME 					= "testdevice-api.com";
	public static final String RESOURCE_TYPE 				= "Hitachi VSP";

	public static final String ENABLE 						= "ENABLE";

	public static final String DISCOVERY_TYPE 				= "RESOURCE";
	public static final String AVAILABILITY 				= "AVAILABILITY";

	public static final String APP 							= "APP";
	public static final String EXCEPTION_DETAILS   			= "exceptionDetails";
	public static final String URL 							= "url";
	public static final String EXCEPTION_CLASS   			= "exceptionSimpleClassName";
	public static final String CURRENT_STATE   		    	= "currentState";
	public static final String CRITICAL   		        	= "Critical";
	
	public static final String ERROR_DETAILS   		    	= "\n Error Details :";
	public static final String API_URL		   		    	= "\n API Url :";
	public static final String INSTALLED_APP_ID   	    	= "\n Installed App ID :";
	public static final String INSTALLED_APP_NAME   		= "\n Installed App Name :";
	public static final String CONFIGURATION_ID   			= "\n Configuration ID :";
	public static final String CONFIGURATION_NAME   		= "\n Configuration Name :";
	public static final String HYPHEN				   		= " - ";
	public static final String APP_NAME 				    = "installedAppName";
	public static final String CONFIG_NAME 	                = "configurationName";

	public static final String CONFIGSTORE 					= "configStore";
	public static final String RESOURCEUUID 				= "resourceUUID";
	public static final String MOID						 	= "moId";
	public static final String RESOURCESTORE 				= "resourceStore";
	public static final String CONFIGMOIDSTORE 				= "configMoIdStore";
	
	public static final String APPSTORE 					= "appStore";
	public static final String RESOURCETYPESTORE 			= "resourceTypeStore";
	
	public static final String READ_FROM_FILE				= "READ_FROM_FILE";
	public static final String EMPTY_STRING					= "";
	
	public static final String TLSV_1POINT2					= "TLSv1.2";
	public static final String HTTPS						= "https";
	
	public static final String HTTP						    = "http";
	public static final String PROTOCOL 				    = "Protocol";
	public static final String IP_ADDRESS 				    = "IP Address";
	public static final String TENANT_ID			 	    = "Tenant Id";
	public static final String API_TOKEN_URL 			    = "Token URL";
	public static final String HOST_NAME                    = "Hostname";
	
	public static final String KEY 				            = "Key";
	public static final String SECRET 				        = "Secret";
	public static final String GRANT_TYPE 				    = "Grant Type";
	
	public static final String METRIC_NAME 			        = "metric";
	public static final String INSTANCE_NAME                = "component";
	public static final String DESKTOP                      = "Desktop";
	
	public static final String VIRTUAL_SERVER               = "hnas_virtualserver_Status";
	public static final String FILESYSTEM_STATUS            = "hnas_filesystem_Status";
	public static final String FILESYSTEM_UTILIZATION       = "hnas_filesystem_Utilization";
	public static final String STORAGEPOOL_CAPACITY         = "hnas_storagepool_Capacityutilization";
	
	public static final int TOKEN_EXPIRY_STATUS_CODE        =  407;
	
	public static final String RESOURCE_PAYLOAD_HASHCODE    = "ResourcePayloadHashCode";
	
	public static final String FINAL_METRIC_DATA 			= "finalMetricData";
	public static final String METRIC_RESPONSE_LIST			= "metricResponseList";
	
	public static final String ENABLE_NOTIF_ALERTS 		= "NotificationAlerts";
	public static final String ALERTNOTIFICATIONSTORE 	= "alertNotificationStore";
	public static final String ALERT_RESOURCE_ID   		= "resourceId";
	public static final String ALERT_TIME   	   		= "alertTime";
	public static final String ALERTTYPE 	 			= "alertType";
	public static final String ALERT_CURRENTSTATE   	= "currentState";
	public static final String ALERT_SERVICENAME   		= "serviceName";
	public static final String SUBJECT					= "subject";
	public static final String ALERT_UUID 				= "uuId";
	public static final String IS_RESOLVED 	        	= " is Resolved";
	public static final String NEW_LINE 	        	= "\n";
	public static final String DESCRIPTION              = "description";
	public static final String OK   		        	= "Ok";
	
	public static final String READ_FILE 				= "read.file";
   // public static final String APP_NAME 				= "sample-app";
    public static final String FILE_PATH 				= "/opt/gateway/content/repo/{0}/config.properties";
	public static final String RESOURCEMOIDSTORE        = "resourcemoIdStore";
	public static final String RETRY_FAILED_API			= "RETRY_FAILED_API";
	
	public static final String DATA                     = "data";
	public static final String COMMMA                   = ",";
	
	public static final String PAYLOAD_RESOURCENAME     = "resourceName";
	public static final String PAYLOAD_IPADDR           = "ipAddress";
	public static final String PAYLOAD_MAKE             = "make";
	public static final String PAYLOAD_MODEL            = "model";
	public static final String PAYLOAD_HOSTNAME         = "hostName";
	public static final String PAYLOAD_ALIASNAME        = "aliasName";
	public static final String PAYLOAD_DNS              = "dns";
	public static final String PAYLOAD_MACADDR          = "macAddress";
	public static final String PAYLOAD_OSNAME           = "osName";
	public static final String PAYLOAD_ID               = "id";
	
	public static final String COLON = ":";
	
	public static final CharSequence RESOURCES          = "resources";
	public static final String FORWORD_SLASH            = "/";
	public static final String ROOT_RESOURCE_HOSTNAME   = "Root Resource HostName";
	public static final String ROOT_RESOURCE_IP_ADDR   	= "Root Resource IPAddress";
	public static final String GATEWAY                  = "OpsRamp Gateway";
	public static final String RELATION_PAYLOAD_STORE   = "relationshipStore";
	
	public static final String RELATION_TYPE		    = "type";
	public static final String SOURCE_MOID     			= "sourceMoId";
	public static final String TARGET_MOID			    = "targetMoId";
	public static final String MEMBER_OF			    = "memberof";
	public static final String DEPENDENDS_ON			= "dependsOn";
	public static final String COMPONENT_OF			    = "componentOf";
	public static final String CONNECTED_TO			    = "connectedTo";
	
	public static final String VCENTER                  = "vCenter";
	public static final String SERVER                   = "Server";
	public static final String VCENTER_NATIVE_TYPE      = "Server";
	public static final String VMS                      = "vm";
	public static final String HOSTS                    = "host";
	public static final String PORT                     = "Port";
	
	public static final String JSON_PAYLOAD             = "payload";
	public static final String PAYLOAD_REFERENCEID      = "referenceId";
	public static final String PAYLOAD_DATA             = "data";
	public static final String PAYLOAD_CREDENTIALIDS    = "credentialIds";
	public static final String PAYLOAD_NATIVETYPES      = "nativeType";
	public static final String PAYLOAD_CONFIG_ID        = "configurationId";
	public static final String PAYLOAD_CONFIG_NAME      = "configurationName";
	public static final String METRIC_URL_JSON			= "MetricBaseUrl.json";
	public static final String NULL_STRING              = "null";

}