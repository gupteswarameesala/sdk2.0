package com.opsramp.app.processor.exception;

@SuppressWarnings("serial")
public class UnknownException extends RuntimeException {

	public UnknownException() {
	}

	public UnknownException(String message) {
		super(message);
	}

	public UnknownException(Throwable cause) {
		super(cause);
	}

	public UnknownException(String message, Throwable cause) {
		super(message, cause);
	}
}

