package com.opsramp.app.processor.api;

/**
 * @author Srini T
 *
 */
public interface APIConstants {
	
	//JSON
	public static final String COLON 						= ":";
	public static final String HYPHEN				     	= " - ";
	public static final String STATUS 						= "status";
	public static final String EMPTY_STRING					= "";
	public static final String COMMA 						= ",";
	
	//Error messages
	public static final String INVALID_API_USERNAME			= "API UserName should not be null or empty.";
	public static final String INVALID_API_PAWWORD			= "API Password should not be null or empty.";
	public static final String INVALID_API_TOKEN_URL		= "API token URL should not be null or empty.";
	public static final String INVALID_JSON_PAYLOAD			= "JsonPayload should not be null or empty.";

	public static final String INVALID_API_KEY				= "API Key should not be null or empty.";
	public static final String INVALID_API_SECRET			= "API Secret should not be null or empty.";
	public static final String INVALID_GRANT_TYPE			= "Grant Type should not be null or empty.";

	//HTTP
	public static final String UTF_8						= "UTF-8";
	public static final String AUTHORIZATION				= "Authorization";
	public static final String ACCEPT						= "Accept";
	public static final String CONTENT_TYPE					= "Content-Type";
	public static final String BEARER						= "bearer ";
	public static final String HTTPS_PROTOCOL				= "https";
	public static final String HTTP_PROTOCOL				= "http";

	//Autontication Headers
	public static final String AUTH_BASIC					= "Basic";
	public static final String AUTH_OAUTH2					= "Oauth2";
	public static final String AUTH_NONE					= "None";
	public static final String BASIC_STR					= "Basic ";
	public static final String BASIC_AUTH_ERROR				= "Cannot encode with UTF-8";

	public static final int CONNECTION_TIME_OUT 			= 120 * 1000; // 2 min 
	
	public static final String GRANT_TYPE 					= "grant_type";
	public static final String OAUTH2_USER_NAME 			= "username";
	public static final String OAUTH2_PASSWORD 				= "password";
	public static final String CLIENT_ID 					= "client_id";
	public static final String CLIENT_SECRET 				= "client_secret";
	public static final String ACCESS_TOKEN 				= "access_token";
		
}
