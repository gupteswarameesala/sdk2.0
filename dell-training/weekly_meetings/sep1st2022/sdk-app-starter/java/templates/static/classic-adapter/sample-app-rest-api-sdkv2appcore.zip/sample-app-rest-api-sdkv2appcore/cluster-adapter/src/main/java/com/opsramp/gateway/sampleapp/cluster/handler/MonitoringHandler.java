package com.opsramp.gateway.sampleapp.cluster.handler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.opsramp.app.content.core.actionhandler.AbstractActionHandler;
import com.opsramp.app.content.util.JsonUtil;
import com.opsramp.app.processor.exception.NoDataFoundException;
import com.opsramp.app.processor.monitor.MonitorDataProcessor;
import com.opsramp.app.util.AppConstants;

public class MonitoringHandler extends AbstractActionHandler {
	
	private static final Logger LOG = LoggerFactory.getLogger(MonitoringHandler.class);
	
	@Override
	public void perform() {
		LOG.error("Inside MonitoringHandler..!! Received monitoring request from Cluster Gateway..!!");
		JsonObject monitoringJsonObj = null;
		try {
			if(this.requestContext.getRequest() == null) { 
				throw new NoDataFoundException("Request Context Should not be null or empty");
			}
			MonitorDataProcessor mointDataProcessor = new MonitorDataProcessor();
			var jsonElement = new Gson().fromJson((String) this.requestContext.getRequest(), JsonElement.class);
			monitoringJsonObj = jsonElement.getAsJsonObject();
			
		    String  configurationId = JsonUtil.getString(monitoringJsonObj, "configurationId");
			LOG.error("Configuration ID is : {}", configurationId);
			// Monitoring request process started
			mointDataProcessor.processMonitoring(configurationId, monitoringJsonObj);
			LOG.error("MonitoringHandler# perform()# Monitoring process ended.. ");
		} catch (Exception e) {
			LOG.error("Failed to process the monitoring request for configuration Id : {} with error : {} ", e.getMessage(), 
					JsonUtil.getString(monitoringJsonObj, AppConstants.PAYLOAD_CONFIG_ID));
		} 
	}
	
}
