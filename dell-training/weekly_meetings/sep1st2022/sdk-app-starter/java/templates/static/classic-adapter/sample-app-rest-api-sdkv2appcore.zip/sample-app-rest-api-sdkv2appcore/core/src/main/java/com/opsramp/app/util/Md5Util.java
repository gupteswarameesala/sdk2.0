package com.opsramp.app.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Md5Util {

	private Md5Util() {
		// Ignore
	}

	public static String getMd5Hash(String value) throws NoSuchAlgorithmException {
		MessageDigest digest = MessageDigest.getInstance(AppConstants.MD5);
		byte[] encodedhash = digest.digest(value.getBytes(StandardCharsets.UTF_8));
		return bytesToHex(encodedhash);
	}

	private static String bytesToHex(byte[] hash) {
		StringBuilder hexString = new StringBuilder(2 * hash.length);
		for (int i = 0; i < hash.length; i++) {
			String hex = Integer.toHexString(0xff & hash[i]);
			if (hex.length() == 1) {
				hexString.append('0');
			}
			hexString.append(hex);
		}
		return hexString.toString();
	}

}
